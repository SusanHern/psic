<?
session_start();
$title = 'Public Service Internship Club Workshops';
require "bootstraptop.php";
require "functions/bootlib.php";
require "../confad.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Categories >>', 'categories.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);


?>
<div class='container-fluid'>
<div class='row text-center'>


<?
$id = $_REQUEST[id];

$sq = $db->query("SELECT * FROM workshop2 WHERE ws_id = '$id'");
while($rowz = $sq->fetchArray(SQLITE3_ASSOC)) { 
echo "$rowz[ws_datefr]<br>";
$datefr = $rowz[ws_datefr];
$title = $rowz[ws_title];
$descp = $rowz[ws_descp];
$image = $rowz[ws_image];
$principle = $rowz[ws_principle];
$price = $rowz[ws_price];
$discount = $rowz[ws_discount];
$criteria = $rowz[ws_discount_criteria];
$time = $rowz[ws_timefr]; 


echo "<div class='col-12'><h1>$title</h1>"; 
echo "<h4>R $price</h4><p>$descp</p><h4>Discount  $discount % for $criteria holders</h4><p>$datefr $time</p> <a style='margin-right:10px;background:#ed8a63;color:gray;' href='buy.php?ws_id=$id' class='btn btn-md text-uppercase'>Buy Now</a><button id='add_em' class='btn btn-md btn-secondary text-uppercase'>Add To Cart</button><div id='resultsp'>r</div><input type='hidden' id='editt' value='$id' /></div>"; } 
?>
</div>




<? 
require "footer.php";
?>




</div><!container>

<?
require "bootstrapbottom.php";
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js" type="text/javascript"></script>
<script>
$(document).ready(function(){ 


$("#resultsp").slideUp();
$("#add_em").click(function(e) { 
        e.preventDefault(); 

        ajax_sepay(); 
});

}); 


function ajax_sepay(){ 

  $("#resultsp").show(); 
  

var fedit = document.getElementById("editt").value;


  $.post("cart.php", {fedits : fedit}, function(data){
   if (data.length>0){ 

   $("#resultsp").html(data); 
   } 
  }) 
}
</script>
