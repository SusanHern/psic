<?
session_start();

require "bootstraptop.php";
require "functions/bootlib.php";
require "../confad.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Categories >>', 'categories.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);

if(isset($_SESSION[customer]) ) {  
?>
<div class='container-fluid'>



<?php
// remove all session variables
session_unset(); 

// destroy the session 
session_destroy(); 
?>

echo "<a href='index.php'>Return Home You have been logged out</a>"; 


<? } 

else { echo "You must be logged in to proceed"; } 
require "footer.php";
?>




</div><!container>

<?
require "bootstrapbottom.php";
?>