<?
$na = $_REQUEST[nam]:
echo "$na";
?>