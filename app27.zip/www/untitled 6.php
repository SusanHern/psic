 <?
 $num = 1027; 
            require "../confad.php";
            $sq = $db->query("UPDATE wsorders SET wo_orderstatus = '3', wo_paymentstatus = '2' WHERE wo_ordernum = '$num'");
            $sm = $db->query("SELECT * FROM wsorders WHERE wo_ordernum = '$num'");
            while ($row = $sm->fetchArray(SQLITE3_ASSOC) ) { 
            $cust = $row[wo_clientid]; } 
            ?>
            $qs = $db->query("DELETE FROM tempord WHERE tm_clientid = '$cust'");