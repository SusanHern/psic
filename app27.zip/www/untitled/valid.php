<?
session_start();
error_reporting(0);
require "www/bootstraptop.php";
require "www/functions/bootlib.php";
require "confone.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Categories >>', 'categories.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);


?>
<div class='container-fluid'>

<div class='row'>
<div class='col-12'>
<?
require "lib.php";
if(isset($_REQUEST[em]) ) { 
$ema = strtolower($_REQUEST[em]);
$ema6 = cr($stp, $emval, $action = "enc");
$sq = $db->query("SELECT * FROM nleta WHERE nl_em = '$ema6' AND ni_va = '1'");
while($row = $sq->fetchArray(SQLITE3_ASSOC) ) { 
$emm = $row[nl_em];
$id = $row[nl_id];
 } 
 if(strlen($emm < 1) ) { 
 echo "You have already validated this email address"; } 
 else { 
 $sqa = $db->query("UPDATE INTO nleta ni_va = '2' WHERE nl_id = '$id'");
 echo "Thank you for validating your address, we will be sending you our Newsletter, from time to time";
 
 } } else { 
 echo "you have accessed the wrong page in error. <a href='index.php'>Return to the home page</a>";
 }
 ?>





<? 
require "www/footer.php";
?>




</div><!container>

<?
require "bootstrapbottom.php";
?>