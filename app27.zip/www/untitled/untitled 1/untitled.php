Merchant ID10010678
Merchant Keyagwrp9i76eqco
Buyer Info
Buyer Emailsbtu01@payfast.co.za
Buyer Passclientpass
Sandbox URLhttps://sandbox.payfast.co.za/eng/process
POST CHECK Open Tools edit

The 'POST CHECK' tool allows you to test your variables and determine what the signature should be, if there are any errors in the ordering, value lengths or if there are any missing required input fields.
Passphrase Clientpass22