<?
session_start();

require "bootstraptop.php";
require "functions/bootlib.php";
require "../confad.php";
require "../lib.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Categories >>', 'categories.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);

if(isset($_SESSION[customer]) ) {  
$customer = cr($stp, ($_SESSION[customer]), $action = 'enc');

$sqlc = $db->query("SELECT * FROM cust1 WHERE cu_phone_mobile = '$customer'");
while($row = $sqlc->fetchArray(SQLITE3_ASSOC) ) { 
$newcustid = $row[cu_id]; } 
?>
<div class='container-fluid'>
<?

echo "<div class='row'>
<div class='col-12 text-center'><h4>Details of your Uncheckedout Orders</h4></div></div>";
echo "<div id='cartDetails'><table width='100%'><tr><td>Workshop</td><td>Price</td><td>Date</td><td>Time</td><td>Discount</td><td>Remove</td></tr>";
$sq = $db->query("SELECT
tempord.tm_id,
        tempord.tm_wsid,
        tempord.tm_clientid,
        workshop2.ws_id,
        workshop2.ws_title,
        workshop2.ws_price,
        workshop2.ws_datefr,
        workshop2.ws_timefr,
        workshop2.ws_timeto,
        workshop2.ws_discount,
        workshop2.ws_descp
FROM tempord  

INNER JOIN workshop2 ON
        tempord.tm_wsid = workshop2.ws_id WHERE tempord.tm_clientid = '$newcustid'");
        while($rowg = $sq->fetchArray(SQLITE3_ASSOC ) ) { 
        $newprice = $rowg[ws_price] - ($rowg[ws_price] * ($rowg[ws_discount]/100));
        
        $totadds[] = $newprice;
        
        echo "<tr><td>$rowg[ws_title]</td>";
echo "<td>R $rowg[ws_price]</td>";
echo "<td>$rowg[ws_datefr]</td>";
echo "<td><b>From:</b> $rowg[ws_timefr]<br>";
echo "<b>To:</b> $rowg[ws_timeto]</td>";
echo "<td>$rowg[ws_discount] %</td><td id='$rowg[tm_id]' onclick='deleteFromCart(this.id);'>x</td></tr>";
        } 
        $total = array_sum($totadds);
        echo "<tr><td colspan='5'></td><td>R $total</td></tr></table></div>";
echo "<a href='cartdets.php' class='btn btn-dark'>Complete Checkout</a><br>";
echo "<div id='resultsh'></div><form name='custdet'><input type='hidden' name='custid' value='$newcustid' /></form>";

?>



<? } 

else { echo "You must be logged in to proceed"; } 
require "footer.php";
?>




</div><!container>

<?
require "bootstrapbottom.php";
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js" type="text/javascript"></script>
<script>

var nam;
function deleteFromCart(nam) { 
$.ajaxSetup({ cache: false });
$("#resultsh").show();

document.getElementById("cartDetails").style.display = "none";
var cu = document.custdet.custid.value;
var url = "deletecart.php?nam="+nam+"&&cu="+cu;
$('#resultsh').load(url);
} 
</script>