<?php
include "bootstraptop.php";
require "functions/bootlib.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Start A Group >>', 'startgroup.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);
$eu = $_REQUEST[em];
echo "$eu<br />";

$eu1 = base64_encode($eu);
include "../confad.php";
$sq = $db->query("SELECT * FROM cust WHERE cu_email = '$eu1' AND cu_pw_status = '1'");
while($r = $sq->fetchArray(SQLITE3_ASSOC)) {
$eum = $r[cu_email]; } 
if($eu1 === $eum) { 
echo "<form name='rform' method='post' action='prchpw.php'><b>Enter Your New Password</b><br /><input type'text' name='psw1'><br /><b>Enter New Password Again</b><input type'text' name='psw2' /><br /><input type'text' value='$eum' name='eu' /><br /><input type='submit' value='Send Email to Change Password' name='submit' /></form>"; } else { 
echo "That is not correct or you have already completed this process. Start again or contact Site Admin for assistance"; } 
?>