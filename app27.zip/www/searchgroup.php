<?
session_start();

require "bootstraptop.php";
require "functions/bootlib.php";
require "../confad.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Categories >>', 'categories.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);


?>
<style>

		
#su{display:none;}
#rr{display:block;}

</style>
<div class='container-fluid'>
<div class='row'>
<div class='col-12'>

<div id='demo'>Co-ordinates By Location</div>
<button class='btn btn-dark' onclick='getLocation();'>View Available Groups in your area</button>
<form action='availp.php' name='myform' method='post'><input type='text' value='' name='lat' /><input type='text' value='' name='lon' />
<input type='submit' name='submit' value='View' /></form><p><h2>Or</h2><h4>View By Address</h4></p><p>EG: 2 mystreet rd, Suburb, Town, South Africa </p><form action='loadmap.php' method='post' name='pform'><input type='text' name='ginput' id='ginput' placeholder='streetname suburb town postalcode' /><input type='text' name='lat' /><input type='text' name='lng' /><input class='btn btn-dark'  id='su' type='submit' name='submit' value='View Group' /></form><div class='btn btn-dark'  id='rr' onclick='geo();'>Click</div><div id='qd'></div><div id='zd'></div>
</div></div>



<? 
require "footer.php";
?>




</div><!container>

<?
require "bootstrapbottom.php";
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js" type="text/javascript"></script>

<script>
var x = document.getElementById("demo");
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else {
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
}
function showPosition(position) {
    x.innerHTML = "Latitude: " + position.coords.latitude + 
    "<br>Longitude: " + position.coords.longitude; 
myform.lat.value = position.coords.latitude;
myform.lon.value = position.coords.longitude;
}
</script>
<script> 
 function geo() {                   
$.ajax({
  url: 'https://geocoder.cit.api.here.com/6.2/geocode.json',
  type: 'GET',
  dataType: 'jsonp',
  jsonp: 'jsoncallback',
  data: {
    searchtext: document.pform.ginput.value,
    app_id: 'aOZ0gFA9M1Q3OwAeU90E',
    app_code: 'HV1Z1K2sggmrpFEXUg9Wtg',
    gen: '8'
  },
  success: function (data) {
    
    
    var str = JSON.stringify(data);
    

    var st = str.indexOf("DisplayPosition")+19;
    var ed = str.indexOf("NavigationPosition")-3;
    var newd = str.substring(st,ed);
    
    var vf = newd.split(',');
        document.pform.lat.value = vf[0].substring(10,vf[0].length);
    document.pform.lng.value = vf[1].substring(12,vf[1].length);
    lax = vf[0].substring(10,vf[0].length);
    lnx = vf[1].substring(12,vf[1].length);
    document.getElementById("su").style.display = "block";
        document.getElementById("rr").style.display = "none";




    
  }
}); } 
</script>