<?
session_start();
$lat = $_POST['lat'];
$lng = $_POST['lon'];
echo "<p> $lat $lng</p>";
require "../confad.php";

$title = 'Public Service Internship Groups In ' . $provincex;
require "bootstraptop.php";
require "functions/bootlib.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Categories >>', 'categories.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);


?>
<div class='container-fluid'>
<div class='row'>
<div class='col-12'><h1 style='font-size:28px;text-align:center;border-bottom:1px solid red;padding:4px;'><? echo "$provincex"; ?></h1><h3>Click on icons to view group details</h3>
<?
echo "<p> $lat $lng</p>";
?>
</div></div>

<script>
var latx = "<?php echo $lat;?>";
var lngx = "<?php echo $lng;?>";
var lat = parseFloat(latx);
var lng = parseFloat(lngx);
</script><script src='geoff.js'></script>


  <div id='container'>
  
 
 <div id="map" style="width: 100%; height: 600px; background: grey" />
  <script  type="text/javascript" charset="UTF-8" >
    
/**
 * Creates a new marker and adds it to a group
 * @param {H.map.Group} group       The group holding the new marker
 * @param {H.geo.Point} coordinate  The location of the marker
 * @param {String} html             Data associated with the marker
 */
function addMarkerToGroup(group, coordinate, html) {
  var marker = new H.map.Marker(coordinate);
  // add custom data to the marker
  marker.setData(html);
  group.addObject(marker);
}

/**
 
 * Clicking on a marker opens an infobubble which holds HTML content related to the marker.
 * @param  {H.Map} map      A HERE Map instance within the application
 */
function addInfoBubble(map) {
  var group = new H.map.Group();

  map.addObject(group);

  // add 'tap' event listener, that opens info bubble, to the group
  group.addEventListener('tap', function (evt) {
    // event target is the marker itself, group is a parent event target
    // for all objects that it contains
    var bubble =  new H.ui.InfoBubble(evt.target.getPosition(), {
      // read custom data
      content: evt.target.getData()
    });
    // show info bubble
    ui.addBubble(bubble);
  }, false);
  var natt = att.split('|');
        
        for (i in natt) {
var markers = natt[i].split(',');
          var name = markers[0];
          
          var type = markers[5];
          var link = markers[3];
          
          
          var la = parseFloat(markers[1]);
          var ln = parseFloat(markers[2]);
          
          var rating = markers[6]; 
          
  addMarkerToGroup(group, {lat: la, lng: ln},
    "<div><a href=\'"+link+"\' >"+name+" </a>" +
    "</div><div>"+type+"</div>");
 } 



}



/**
 * Boilerplate map initialization code starts below:
 */

// initialize communication with the platform
var platform = new H.service.Platform({
  app_id: 'I9Y4iDApiDnRYg4Bcfyx',
  app_code: '8DVGvwPLV6UgKJWVU5-p3A',
  useCIT: true,
  useHTTPS: true
});
var pixelRatio = window.devicePixelRatio || 1;
var defaultLayers = platform.createDefaultLayers({
  tileSize: pixelRatio === 1 ? 256 : 512,
  ppi: pixelRatio === 1 ? undefined : 320
});

// initialize a map - this map is centered over Europe
var map = new H.Map(document.getElementById('map'),
  defaultLayers.normal.map,{
  center: {lat: lat, lng: lng},
  zoom: 7,
  pixelRatio: pixelRatio
});

// MapEvents enables the event system
// Behavior implements default interactions for pan/zoom (also on mobile touch environments)
var behavior = new H.mapevents.Behavior(new H.mapevents.MapEvents(map));

// create default UI with layers provided by the platform
var ui = H.ui.UI.createDefault(map, defaultLayers);

// Now use the map as required...
addInfoBubble(map);
  </script>


   
</div></div>




<?
require "footer.php"; 
?>


</div><!container>

<?
require "bootstrapbottom.php";
?>