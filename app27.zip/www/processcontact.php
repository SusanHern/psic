<?

require "bootstraptop.php";
require "functions/bootlib.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Start A Group >>', 'startgroup.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);
?>

<div class='container-fluid'>

      <div class="row">
        <div class="col-12">
          <center><h2>Contact Details</h2></center><hr>
          <p></div></div>
<div class="row">
<hr>
  <div class="col-md-12"><h4>Message</h4><br /><hr><p>
  
<?php

$ch = $_POST[chkhuman];
$email = $_POST["email"];
echo "$email<br>";
$name = $_POST["name"];
echo "Thank you, message received.";
if(EMPTY($_POST["chkhuman"]) ) { 
echo "please add the Robot checker sum";
} 
elseif($_POST["chk"] != $_POST["chkhuman"]) { 
echo "That is incorrect, please try again"; } 
elseif(filter_var($email, FILTER_VALIDATE_EMAIL) != true) { 
echo "Email is in the incorrect format"; } 
elseif(EMPTY($_POST["name"]) || EMPTY($_POST["email"]) ) { 
echo "Add details"; } else { 
$name = $_POST[name];
$email = $_POST[email];
$to  = 'susan.hern@icloud.com';
$message = strip_tags($_POST[message]);
// subject
$subject = 'Message From ' . " $name";

// message
$message = '
<html><head><title>You have received an online query</title></head>
<body><p>From !' . $name . '</p><table><tr><th>' . $email. '</th><th>' . $message . '</th></tr></table></body></html>';

// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// Additional headers

$headers .= 'From: ' . $name . ' <' . $email . '>' . "\r\n";


// Mail it
mail($to, $subject, $message, $headers); } 

?></div></div>
<div  style='background: black;color:white;' class='row text-center'>

<div  class='col-12'>
<h2>Footer</h2>
<h4>Sub Footer</h4></div>
</div>


<?
echo "<div  style='background: black;color:white;padding:12px;' class='row'>";
echo "<div  class='col-4'>";
echo "<b style='color:silver;'>Provincial Groups</b>";
$sizesx = 9;
$stylex = 'liststy';
$listx = 'ul';
$clax = 'list-unstyled';
$contx = array("Eastern Cape", "Free State", "Gauteng", "KwaZulu-Natal", "Limpop", "Mpumalanga", "Northern Cape", "North West");
$optstylex = array('tt1', 'tt2', 'tt3', 'tt4', 'tt5', 'tt6');
$lisx = blist($stylex, $listx, $clax, $sizex, $contx, $optstylex);
echo $lisx;
?>




</div>
<div  class='col-4'><b style='color:silver;'>Featured Groups</b></div>
<div  class='col-4'><b style='color:silver;'>Services</b></div>
</div>

<div  style='background: black;color:white;' class='row text-center'>

<div  class='col-12'>
<p class="m-0 text-center text-white">Copyright &copy; Public Service Internship Club 2018</p><p style='text-align:center;'><i class="fab fa-twitter fa-1x" style='color:#d9534f;'></i><i class="fab fa-instagram fa-1x" style='color:#d9534f;'></i><i class="fab fa-facebook-f fa-1x" style='color:#d9534f;'></i></p>
</div>

</div>


</div><!container>

<?
require "bootstrapbottom.php";
?>
  


