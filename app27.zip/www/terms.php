<?
require "bootstraptop.php";
require "functions/bootlib.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Start A Group >>', 'startgroup.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);
?>

<div class='container-fluid'>

<div class='row'>

<div id='headimage' class='col-12 text-center'>
<h1 style='margin-top:550px;' >Public Service Internship Club</h1><h4 style='margin-top:30px;' >Some Text</h4><p><a class="btn btn-block btn-danger" href="register.php" role="button">Join</a></p><p style='margin-top:50px;'>More text</p>
</div>

</div>

<?
require "footer.php";
?>


</div><!container>

<?
require "bootstrapbottom.php";
?>