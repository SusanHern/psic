<?
session_start();
$newcart = $_REQUEST[nam];
echo "new $newcart";
require "../confad.php";
require "../lib.php";
error_reporting(0);
if(!EMPTY($_REQUEST[cu]) ) { 
$newcustid = $_REQUEST[cu];

$rq = $db->query("DELETE FROM tempord WHERE tm_id = '$newcart'");



echo "<div id='cartDetails'><table width='100%'><tr><td>Workshop</td><td>Price</td><td>Date</td><td>Time</td><td>Discount</td><td>Remove</td></tr>";
$sq = $db->query("SELECT
tempord.tm_id,
        tempord.tm_wsid,
        tempord.tm_clientid,
        workshop2.ws_id,
        workshop2.ws_title,
        workshop2.ws_price,
        workshop2.ws_datefr,
        workshop2.ws_timefr,
        workshop2.ws_timeto,
        workshop2.ws_discount,
        workshop2.ws_descp
FROM tempord  

INNER JOIN workshop2 ON
        tempord.tm_wsid = workshop2.ws_id WHERE tempord.tm_clientid = '$newcustid'");
        while($rowg = $sq->fetchArray(SQLITE3_ASSOC ) ) { 
        $newprice = $rowg[ws_price] - ($rowg[ws_price] * ($rowg[ws_discount]/100));
        
        $totadds[] = $newprice;
        
        echo "<tr><td>$rowg[ws_title]</td>";
echo "<td>R $rowg[ws_price]</td>";
echo "<td>$rowg[ws_datefr]</td>";
echo "<td><b>From:</b> $rowg[ws_timefr]<br>";
echo "<b>To:</b> $rowg[ws_timeto]</td>";
echo "<td>$rowg[ws_discount] %</td><td id='$rowg[tm_id]' onclick='deleteFromCart(this.id);'>x</td></tr>";
        } 
        $total = array_sum($totadds);
        echo "<tr><td colspan='5'></td><td>R $total</td></tr></table></div>"; } else { 
        echo "no data submitted"; } 

?>
