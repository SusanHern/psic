 echo "<select name='repeat'>";
 echo "<option value='daily'>Daily</option>";
  echo "<option value='weekly'>Weekly</option>";
   echo "<option value='bi_weekly'>Bi-Weekly</option>";
   echo "<option value='bi_monthly'>Bi-Monthly</option>";
    echo "<option value='monthly'>Monthly</option>";
    echo "</select>";