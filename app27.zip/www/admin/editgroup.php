<?
require "bootstraptop.php";
require "slide.php";
include "../functions/bootlib.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../lib.php";
include "../../confadmin.php";
echo "<form action='processeditgroups.php' method='post'>";
echo "<h4>Enter Group Details</h4><p>Each group may be inserted into one matching category. </p><br /><select name='cate'>";
$id = $_REQUEST[id];
$sql = $db->query("SELECT * FROM groupcl WHERE gr_id = '$id'");
while($rows = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
$title = $rows[gr_title];
$descp = $rows[gr_descp]; 

$idd = $rows[gr_id];
$img = $rows[gr_image];
$address1 = $rows[gr_address1];
$address2 = $rows[gr_address2];
$suburb = $rows[gr_suburb];
$town = $rows[gr_town];
$province = $rows[gr_province];
$zip = $rows[gr_zip];
$mobile = $rows[gr_mobile];
$phone = $rows[gr_phone];
$lat = $rows[gr_lat];
$lng = $rows[gr_lng];
$status = $rows[gr_status];

} 
$sql = $db->query("SELECT * FROM groupcate");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 

echo "<option value='$row[gc_id]'>$row[gc_title] </option>"; } 
echo "</select><br>";
 

           echo "<label>Group Name</label><br><input id='addtype' value='$title' name='addtype' /><label>Group Image</label><br>
           <input id='img' value='$img' name='img' type='text'><br>
           <label>Group Description</label><br>
           <textarea rows='10' cols='30' name='descp'>$descp</textarea><br>";
               

 $input_labelc1 = 'Street Name and Number';
 $input_typec1 = 'text';
 $sizec1 = 'col-xs-8 col-md-12';
 $input_idc1 = 'address1';
 $va1 = $address1;
 input_formv($input_idc1, $input_typec1, $input_labelc1, $sizec1, $va1);
  $input_labelc2 = 'Building/Unit Name and Number';
 $input_typec2 = 'text';
 $sizec2 = 'col-xs-8 col-md-12';
 $input_idc2 = 'address2';
 $va2 = $address2;
 input_formv($input_idc2, $input_typec2, $input_labelc2, $sizec2, $va2);
 $input_labelc3 = 'Suburb';
 $input_typec3 = 'text';
 $sizec3 = 'col-xs-8 col-md-12';
 $input_idc3 = 'suburb';
 $va3 = $suburb;
 input_formv($input_idc3, $input_typec3, $input_labelc3, $sizec3, $va3);
  $input_labelc4 = 'Town';
 $input_typec4 = 'text';
 $sizec4 = 'col-xs-8 col-md-12';
 $input_idc4 = 'town';
 $va4 = $town;
 input_formv($input_idc4, $input_typec4, $input_labelc4, $sizec4, $va4);
 $input_labelc5 = 'Zip';
 $input_typec5 = 'text';
 $sizec5 = 'col-xs-8 col-md-8';
 $input_idc5 = 'zip';
 $va5 = $zip;
 input_formv($input_idc5, $input_typec5, $input_labelc5, $sizec5, $va5);
 echo "<select name='state'>";
 $sqq = $db->query("SELECT * FROM locate");
 while($ro = $sqq->fetchArray(SQLITE3_ASSOC) ) { 
 echo "<option value='$ro[lc_id]'>$ro[lc_title]</option>";
 } 
 echo "</select><br>";
 $input_labelc7 = 'Email';
 $input_typec7 = 'email';
 $sizec7 = 'col-xs-8 col-md-12';
 $input_idc7 = 'email';
 $va7 = $email;
 input_formv($input_idc7, $input_typec7, $input_labelc7, $sizec7, $va7);
 
 $input_labelc8 = 'Landline';
 $input_typec8 = 'number';
 $sizec8 = 'col-xs-8 col-md-8';
 $input_idc8 = 'landline';
 $va8 = $phone;
 input_formv($input_idc8, $input_typec8, $input_labelc8, $sizec8, $va8);
  $input_labelc9 = 'Mobile';
 $input_typec9 = 'number';
 $sizec9 = 'col-xs-8 col-md-8';
 $input_idc9 = 'mobile';
 $va9 = $mobile;
  input_formv($input_idc9, $input_typec9, $input_labelc9, $sizec9, $va9);
   $input_labelc9d = 'Latitude';
 $input_typec9d = 'text';
 $sizec9d = 'col-xs-8 col-md-8';
 $input_idc9d = 'lat';
 $va9d = $lat;
  input_formv($input_idc9d, $input_typec9d, $input_labelc9d, $sizec9d, $va9d);
    $input_labelc9p = 'Longitude';
 $input_typec9p = 'text';
 $sizec9p = 'col-xs-8 col-md-8';
 $input_idc9p = 'lng';
 $va9p = $lng;
  input_formv($input_idc9p, $input_typec9p, $input_labelc9p, $sizec9p, $va9p);
      $input_labelc9k = '';
 $input_typec9k = 'text';
 $sizec9k = 'col-xs-8 col-md-8';
 $input_idc9k = 'id';
 $va9k = $idd;
  input_formv($input_idc9k, $input_typec9k, $input_labelc9k, $sizec9k, $va9k);
 ?>
 
                  <button id='add_em' class='btn btn-danger' type='submit'> 
                     Go! 
                  </button></form<p><div id='results'>gg</div></p>




</div></div>

<div class='row'>
<div class='col-12'>
<?
$sql = $db->query("SELECT * FROM groupcl");
while($rows = $sql->fetchArray(SQLITE3_ASSOC ) ) { 


echo "$rows[gr_title]<br />";

echo "$rows[gr_descp]<br />"; 
echo "<a href='editgroup.php?id=$rows[gr_id]'>$rows[gr_title]</a>"; } 
?>
</div></div>
</div></body></html>
