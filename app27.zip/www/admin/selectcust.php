   CREATE TABLE cust1
      (cu_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
cu_ps, cu_psqu, cu_psas, cu_fname,  cu_lname, cu_contact_title, cu_email, cu_address_streetnum, cu_address_streetname, cu_address_buildingnum, cu_address_buildingname, cu_address_suburb, cu_address_town, cu_address_province, cu_address_country, cu_address_postalcode, cu_phone_land, cu_wh_number, cu_phone_mobile, cu_phone_fax, cu_descp, cu_type, cu_newsletter,   cust_em_idcu, cu_dayfirst, cu_subscriptionstatus, cu_subscriptiondate, cu_subscriotionamount, cu_subscritionvouchers, cu_subscribtionid
<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../lib.php";
include "../../confadmin.php";
$sq = $db->query("SELECT * FROM cust1");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 
$phone = cr($stp, $row[cu_phone_mobile], $action = 'ivg');
echo "$phone<br>";
echo "id $row[cu_id]<br>";
} 
?>
</div></div>
</div></body></html>