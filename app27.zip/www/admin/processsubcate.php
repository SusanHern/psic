
<?
require "bootstraptop.php";
require "slide.php";
require "../functions/libsql.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?

$tb = "subcate";
$connection = "../../confadmin.php";
if (EMPTY($_POST[addtype]) ) { 
echo "Please enter a title"; } else { 
$cate = $_POST[cate];
$title = $_POST[addtype];
$image = $_POST[img];
$descp = $_POST[descp];
echo "cate $cate title $title img $image description $descp";

$fieldsarray = array("subcate_gcid", "subcate_title", "subcate_descp", "subcate_image");
$fieldsarray2 = array($cate, $title, $image, $descp);

instb($connection, $tb, $fieldsarray, $fieldsarray2); } 
?>
</div></div>
</div></body></html>