pt_title, pt_descp, pt_images, pt_processtype
<?
require "../functions/libsql.php";
$connection = "../../confadmin.php";
$tb = "paytypes";
$cate = $_POST[payt];
$descps = $_POST[pay_descp];
echo "$cate";
?>



$fieldsarray = array("pt_title" , "pt_descp");
$fieldsarray2 = array($cate, $descp);

instb($connection, $tb, $fieldsarray, $fieldsarray2);
