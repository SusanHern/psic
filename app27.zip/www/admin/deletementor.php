<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../bootlib.php";
include "../../confadmin.php";
$ptype = $_REQUEST[id];
echo "$ptype added to data<br>";
$db->exec("DELETE FROM mentor WHERE mn_id = '$ptype'");
?>
</div></div>
</div></body></html>