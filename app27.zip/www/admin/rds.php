<?
$xml=simplexml_load_file("coord.xml");

function simpleXmlObjectToArray ( $xmlObject, $out = array () )
{
    foreach ( (array) $xmlObject as $index => $node )
        $out[$index] = ( is_object ( $node ) || is_array($node) )
        ? simpleXmlObjectToArray ( $node )
        : $node;

    return $out;
}

$wq = simpleXmlObjectToArray($xml, $out = array());
print_r($wq);
$ad = $wq[Response][Location];
foreach ($wq as $df) { 
foreach ($df as $zf) { 
foreach ($zf as $gf) { 
  
echo "qw $gf";

} } 
} 
?>

  ?>