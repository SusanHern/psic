<?
require "bootstraptop.php";
require "slide.php";
include "../../bootlib.php";
include "../../confadmin.php";

?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?


$id = $_REQUEST["id"];
echo "$id";
$sq = $db->query("SELECT * FROM wsorders WHERE wo_id ='$id'");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 
echo "$row[wo_id]<br>";
echo "id $row[wo_ordernum]<br>";
echo "client $row[wo_clientid]<br>";
echo "product $row[wo_producttype]<br>";
echo "price $row[wo_price]<br>";
echo "date $row[wo_orderdate]<br>";
echo "time $row[wo_ordertime]<br>";
echo "discount $row[wo_discounttype]<br>";
echo "Dis amount $row[wo_discountamoung]<br>";
echo "features $row[wo_orderfeatures]<br>";
echo "status $row[wo_orderstatus]<br>";
echo "pay type $row[wo_paymenttype]<br>";
echo "status $row[wo_paymentstatus]<br>";

echo "<a href='index.php'>Home</a></br>";
echo "<a href='issuerefund.php?id=$id'>Issue Refund</a></br>";
} 
?></div></div></div>