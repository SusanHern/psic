br_title, br_descp, br_image, br_supplierid
caption" , "link", "descp", "img", "byline
<?

require "../functions/libsql.php";


$connection = "../../confadmin.php";
$tb = "ordnum";
$cate = 1001;





$fieldsarray = array("od_num");
$fieldsarray2 = array($cate);

instb($connection, $tb, $fieldsarray, $fieldsarray2);
?>

ordnum
od_id
od_num