<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../lib.php";
include "../../confadmin.php";
$title = $_POST[addtitle];
$descp = $_POST[adddescp];
$image = $_POST[addimage];
$id = $_POST[id];
echo "$title $descp $image $id<br>";

$sq = $db->query("UPDATE groupcate SET gc_title = '$title', gc_descp = '$descp', gc_image = '$image' WHERE gc_id = '$id'");
?>
</div></div>
</div></body></html>
