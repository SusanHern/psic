<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../lib.php";
include "../../confadmin.php";
$sq = $db->query("SELECT * FROM wsorders");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 


echo "id $row[wo_ordernum]<br>";
echo "client $row[wo_clientid]<br>";
echo "product $row[wo_producttype]<br>";
echo "price $row[wo_price]<br>";
echo "date $row[wo_orderdate]<br>";
echo "time $row[wo_ordertime]<br>";
echo "discount $row[wo_discounttype]<br>";
echo "Dis amount $row[wo_discountamoung]<br>";
echo "features $row[wo_orderfeatures]<br>";
echo "status $row[wo_orderstatus]<br>";
echo "pay type $row[wo_paymenttype]<br>";
echo "status $row[wo_paymentstatus]<br>";
echo "Group $row[wo_groupid]<br>";
echo "Workshop $row[wo_wsid]<br>";
echo "<hr>";

} 
?>
</div></div>
</div></body></html>
