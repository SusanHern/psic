<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-6'>
<?
include "../../lib.php";
include "../../confadmin.php";

echo "<form action='processlocate.php' method='post'>";
echo "<h4>Enter Locations</h4>";
 

           echo "<label>Location Name</label><input id='title' name='title' type='text'><br><label>Location Latitude</label>
           <input id='lat' name='lat' type='text'><br>
           <label>Location Longtitude</label>
           <input id='lng' name='lng' type='text'><br>

               
                  <button id='add_em' class='btn btn-primary' type='submit'> 
                     Go! 
                  </button></form<p><div id='results'>gg</div></p>"; 


?>
</div>
<div class='col-6'>

<?php
echo "<h4>Edit Type</h4><p>SubTypes serve as categories for workshops. </p><br />";
$sql = $db->query("SELECT * FROM locate LIMIT 0, 30 ");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 

echo "<a href='editlocate.php?ty=$row[lc_id]'><i class='far fa-edit'></i> $row[lc_title] $row[lc_id]</a>|<a href='deletelocate.php?ty=$row[lc_id]'><i class='far fa-trash'></i> $row[lc_title]</a><br />"; } 
?>

</div>
</div>


</div></div>
</div></body></html>
