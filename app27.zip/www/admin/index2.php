<?
require "bootstraptop.php";
require "slide.php";
include "../../bootlib.php";
include "../../confadmin.php";
?>

<?php

$sql = $db->query("SELECT * FROM locate LIMIT 0, 30 ");
while($rowx = $sql->fetchArray(SQLITE3_ASSOC ) ) { 

$locateid = "$rowx[lc_id]";
$locatetitle[] = $rowx[lc_title]; } 
?>
<div class='container-fluid'><div class='row'>
<div class='col-12'>
<canvas id="myChart"></canvas>
</div></div>
<div class='col-12'>
<canvas id="myChartr"></canvas>
</div></div>

<div class='row text-center'>
<div class='col-12 text-center'>
<h4>Manage Orders</h4>
<?

$sq = $db->query("SELECT * FROM wsorders WHERE wo_producttype = 'workshop' ORDER BY wo_id DESC LIMIT 6");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 


echo "<a href='vieword.php?id=$row[wo_id]'>View Order Number $row[wo_ordernum] Order Status $row[wo_orderstatus]</a>|<a href='refundord.php?id=$row[wo_id]'>Refund Order Number $row[wo_ordernum] Order Status $row[wo_orderstatus]</a></br><br>";
} 
echo "<a class='btn btn-dark' href='ordersview.php'>View More</a>";
?>


</div></div>
<div style='margin-top:2em;' class='row'>
<div class='col-6'>
<h4>Subscriptions Per Area</h4>
<div id="canvas-holder">
<canvas id="chart-area"></canvas>
	</div></div><div class='col-6'>
<h4>Manage Subscriptions</h4>
<?

$sq = $db->query("SELECT * FROM wsorders WHERE wo_producttype = 'subscription'");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 


echo "<a href='viewsub.php?id=$row[wo_id]'>Order Number $row[wo_ordernum] Order Status $row[wo_orderstatus]</a></br>";
} 
?></div></div></div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>

<script>
var ctx = document.getElementById('myChart').getContext('2d');
var chart = new Chart(ctx, {
    // The type of chart we want to create
    type: 'line',

    // The data for our dataset
    data: {
        labels: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
        datasets: [{
            label: "SALES PER MONTH",
            backgroundColor: 'rgb(255, 99, 132)',
            borderColor: 'rgb(255, 99, 132)',
            data: [0, 10, 5, 2, 20, 30, 45, 10, 50, 20, 30, 20],
        }]
    },

    // Configuration options go here
    options: {}
});
</script>
<script>
var fst = "<? echo $locatetitle[0]; ?>";
var fst1 = "<? echo $locatetitle[1]; ?>";
var fst2 = "<? echo $locatetitle[2]; ?>";
var fst3 = "<? echo $locatetitle[3]; ?>";
var fst4 = "<? echo $locatetitle[4]; ?>";
var fst5 = "<? echo $locatetitle[5]; ?>";
var fst6 = "<? echo $locatetitle[6]; ?>";
var fst7 = "<? echo $locatetitle[7]; ?>";
var fst8 = "<? echo $locatetitle[8]; ?>";
	var ctx = document.getElementById("chart-area").getContext('2d');
var myChart = new Chart(ctx, {
  type: 'pie',
  data: {
    labels: [fst, fst1, fst2, fst3, fst4, fst5, fst6, fst7, fst8],
    datasets: [{ 
    
      backgroundColor: [
        "#2ecc71",
        "#3498db",
        "#95a5a6",
        "#9b59b6",
        "#f1c40f",
        "#e74c3c",
        "#34495e",
        "00ff00",
        "#00ffff"
      ],
      data: [12, 19, 3, 17, 28, 24, 7, 12, 18]
    }]
  }
});

</script>
<script>
var ctx = document.getElementById('myChartr').getContext('2d');
var myChart = new Chart(ctx, {
  type: 'line',
  data: {
    labels: ['M', 'T', 'W', 'T', 'F', 'S', 'S'],
    datasets: [{
      label: 'Completed Sales',
      data: [12, 19, 3, 17, 6, 3, 7],
      backgroundColor: "rgba(153,255,51,0.4)"
    }, {
      label: 'Abandoned Sales',
      data: [2, 29, 5, 5, 2, 3, 10],
      backgroundColor: "rgba(255,153,0,0.4)"
    }]
  }
});
</script>


   
<?
require "../bootstrapbottom.php";
?>