<?
require "../../confadmin.php";
$ptype = $_REQUEST[ty];
echo "$ptype added to data<br>";
$db->exec("DELETE FROM groupcl WHERE gr_id = '$ptype'");