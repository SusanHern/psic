<?
require "bootstraptop.php";
require "slide.php";
include "../../bootlib.php";
include "../../confadmin.php";
?>
<div class='container-fluid'>
<div class='row'>
<div class='col-12 text-center'>
<h1>Workshop Orders</h1><hr>
</div></div>

<?
$searchTerm = 'workshop';
    $stmf = "SELECT * FROM wsorders WHERE wo_producttype = '$searchTerm'";
       $resf = $db->query($stmf);
            while($rof = $resf->fetchArray(SQLITE3_ASSOC)) { 
            
            $tot[] = $rof[wo_price];
            
            
            
  }
       $stm = "SELECT COUNT(*) FROM wsorders WHERE wo_producttype = '$searchTerm'";
       $res = $db->query($stm);
            while($ro = $res->fetchArray(SQLITE3_ASSOC)) { 
            $records = $ro['COUNT(*)'];
            $tot[] = $row[wo_price];
            
            
            
  }
  
 $recordsperpage = 6;
  
  $url = "ordersview.php";
  echo "<div class='row'><div class='col-12'>";
 require "../paging.php";
 
  include "../pagx.php";
  echo "</div></div>";
  
  ?>
<div class='row text-center'>
<div class='col-12 text-center'>
<h4>Manage Orders</h4>
<?

$sq = $db->query("SELECT * FROM wsorders WHERE wo_producttype = 'workshop' ORDER BY wo_id DESC LIMIT $nu, $recordsperpage");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 


echo "<a href='vieword.php?id=$row[wo_id]'>Order Number $row[wo_ordernum] Order Status $row[wo_orderstatus] Price $row[wo_price] </a></br><br>";
} 
$total = array_sum($tot);
echo "<p>R $total</p>";
?>


</div></div></div>

   
<?
require "../bootstrapbottom.php";
?>