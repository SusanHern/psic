<?
require "../../confadmin.php";
$searchTerm = 'workshop';
       $stm = "SELECT COUNT(*) FROM wsorders WHERE wo_producttype = '$searchTerm'";
       $res = $db->query($stm);
            while($ro = $res->fetchArray(SQLITE3_ASSOC)) { 
            $records = $ro['COUNT(*)'];
            echo "$records<br>";
            
  }
  
 $recordsperpage = 6;
  
  $url = "categorygroup.php";
  echo "<div class='row'><div class='col-md-12'>";
 require "../paging.php";
 echo "<br />";
  include "../pagx.php";
  echo "</div></div>";
  echo "<hr>";
$sq = $db->query("SELECT * FROM wsorders WHERE wo_producttype = 'workshop' ORDER BY wo_id DESC LIMIT $nu, $recordsperpage");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 


echo "<a href='viewsub.php?id=$row[wo_id]'>Order Number $row[wo_ordernum] Order Status $row[wo_orderstatus]</a></br>";
} 
?>