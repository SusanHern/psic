<?
$xml=simplexml_load_file("coord.xml");

foreach($xml->Response as $xx) { 

$view = $xx->View->Result->Location->DisplayPosition->Latitude;
echo "<b>Latitude: </b> $view<br>";
$view2 = $xx->View->Result->Location->DisplayPosition->Longitude;
echo "<b>Longitude: </b> $view2<br>";
  
 
      
   } 