<?
require "bootstraptop.php";
require "../functions/libsql.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
$tb = "businessname";
require  "../../confadmin.php";
$id = intval($_POST[id]);
if (EMPTY($_POST[title] ) ) { 
echo "You must add a name"; } 
elseif (EMPTY($_POST[phrase] ) ) { 
echo "Please enter a short phrase"; } 
elseif(EMPTY($POST[product]) ) { 
echo "A product must be added"; } else { 
$webname = cl($_POST[title]);
$phrase = cl($_POST[phrase]);
$industry = cl($_POST[industry]);
$bgimg = $_POST[bgimg];
$logo = $_POST[logo];
$product = cl($_POST[product]);

echo "webname $webname phrase $phrase  bgimg $bgimg logo $logo product $product industry $industry";
$fieldsarray2 = array($webname, $phrase, $logo, $bgimg, $industry, $product);
$fieldsarray = array("webname", "catchphrase", "logo" , "backgroundimg" , "industry", "producttype");
$sq = $db->query("UPDATE businessname SET $fieldsarray[0] = '$fieldsarray2[0]',  $fieldsarray[1] = '$fieldsarray2[1]',  $fieldsarray[2] = '$fieldsarray2[2]',  $fieldsarray[3] = '$fieldsarray2[3]',  $fieldsarray[4] = '$fieldsarray2[4]',  $fieldsarray[5] = '$fieldsarray2[5]' WHERE bus_id = '$id'");

echo "<a href='index.php'>Return Home data added</a>"; } 
?>


</div></div>
</div></body></html>