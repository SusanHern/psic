<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-6'>
<script>
function validateForm()
{
var x=document.forms["rform"]["address1"].value;
if (x==null || x=="")
  {
  alert("Street Name must be filled out");
  return false;
  } 


var xc=document.forms["rform"]["suburb"].value;
if (xc==null || xc=="")
  {
  alert("suburb must be filled out");
  return false;
  } 
  var xc1=document.forms["rform"]["town"].value;
if (xc1==null || xc1=="")
  {
  alert("town must be filled out");
  return false;
  } 
   var xc2=document.forms["rform"]["zip"].value;
if (xc1==null || xc1=="")
  {
  alert("postalcode must be filled out");
  return false;
  } 



}
</script>

<?

include "../../confadmin.php";
include "../functions/bootlib.php";
require "../../lib.php";
 echo "<div class='container-fluid'><form name='rform' onsubmit='return validateForm();' action='processbusinessaddress.php' method='post'>";
 $input_labela = 'Address Name(eg: Headoffice) ';
 $input_typea = 'text';
 $sizea = 'col-xs-8 col-md-12';
 $input_ida = 'title';
 input_form($input_ida, $input_typea, $input_labela, $sizea);
 

 $input_labelc1 = 'Street Name and Number';
 $input_typec1 = 'text';
 $sizec1 = 'col-xs-8 col-md-12';
 $input_idc1 = 'address1';
 input_form($input_idc1, $input_typec1, $input_labelc1, $sizec1);
  $input_labelc2 = 'Building/Unit Name and Number';
 $input_typec2 = 'text';
 $sizec2 = 'col-xs-8 col-md-12';
 $input_idc2 = 'address2';
 input_form($input_idc2, $input_typec2, $input_labelc2, $sizec2);
 $input_labelc3 = 'Suburb';
 $input_typec3 = 'text';
 $sizec3 = 'col-xs-8 col-md-12';
 $input_idc3 = 'suburb';
 input_form($input_idc3, $input_typec3, $input_labelc3, $sizec3);
  $input_labelc4 = 'Town';
 $input_typec4 = 'text';
 $sizec4 = 'col-xs-8 col-md-12';
 $input_idc4 = 'town';
 input_form($input_idc4, $input_typec4, $input_labelc4, $sizec4);
 $input_labelc5 = 'Zip';
 $input_typec5 = 'text';
 $sizec5 = 'col-xs-8 col-md-8';
 $input_idc5 = 'zip';
 input_form($input_idc5, $input_typec5, $input_labelc5, $sizec5);
 $input_labelc6 = 'State';
 $input_typec6 = 'text';
 $sizec6 = 'col-xs-8 col-md-12';
 $input_idc6 = 'state';
 input_form($input_idc6, $input_typec6, $input_labelc6, $sizec6);
 $input_labelc7 = 'Email';
 $input_typec7 = 'email';
 $sizec7 = 'col-xs-8 col-md-12';
 $input_idc7 = 'email';
 input_form($input_idc7, $input_typec7, $input_labelc7, $sizec7);
 
 $input_labelc8 = 'Landline';
 $input_typec8 = 'number';
 $sizec8 = 'col-xs-8 col-md-8';
 $input_idc8 = 'landline';
 input_form($input_idc8, $input_typec8, $input_labelc8, $sizec8);
  $input_labelc9 = 'Mobile';
 $input_typec9 = 'number';
 $sizec9 = 'col-xs-8 col-md-8';
 $input_idc9 = 'mobile';
 input_form($input_idc9, $input_typec9, $input_labelc9, $sizec9);
$id = $_REQUEST[id];
echo "<input type='text' value='$id' name='nameid' />";
 
echo "<button class='btn btn-lg btn-primary btn-block' type='submit' name='submit'>Submit</button><br />";
 echo "</form></div>";
 ?>
          
</p>

</div>
<div class='col-6'>
</div>


</div>
</div></body></html>