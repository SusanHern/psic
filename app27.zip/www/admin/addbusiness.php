<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-6'>
<h4>Add Business Details</h4>
<script>
function validateForm()
{
var x=document.forms["rform"]["title"].value;
if (x==null || x=="")
  {
  alert("Name must be filled out");
  return false;
  } 


var xc=document.forms["rform"]["phrase"].value;
if (xc==null || xc=="")
  {
  alert("phrase must be filled out");
  return false;
  } 
  var xc1=document.forms["rform"]["product"].value;
if (xc1==null || xc1=="")
  {
  alert("product must be filled out");
  return false;
  } 
   var xc2=document.forms["rform"]["industry"].value;
if (xc1==null || xc1=="")
  {
  alert("industry must be filled out");
  return false;
  } 



}
</script>
<?

include "../../confadmin.php";
include "../functions/bootlib.php";
require "../../lib.php";
 echo "<div class='container-fluid'><h1>Do not re-enter data info for your business if you've already completed this form. Edit any details(right-hand side of page) you want to change.</h1><form onsubmit='return validateForm();' name='rform' action='processbusiness.php' method='post'>";
 $input_labela = 'Name of Business/Website';
 $input_typea = 'text';
 $sizea = 'col-xs-8 col-md-8';
 $input_ida = 'title';
 input_form($input_ida, $input_typea, $input_labela, $sizea);
 $input_label = 'Image Logo File:200px wide';
 $input_type = 'text';
 $size = 'col-xs-8 col-md-8';
 $input_id = 'logo';
 input_form($input_id, $input_type, $input_label, $size);
 $input_labelb = '3 word catch phrase';
 $input_typeb = 'text';
 $sizeb = 'col-xs-8 col-md-8';
 $input_idb = 'phrase';
 input_form($input_idb, $input_typeb, $input_labelb, $sizeb);
 $input_labelc = 'Product Type';
 $input_typec = 'text';
 $sizec = 'col-xs-8 col-md-8';
 $input_idc = 'product';
 input_form($input_idc, $input_typec, $input_labelc, $sizec);
  $input_labeln = 'Industry';
 $input_typen = 'text';
 $sizen = 'col-xs-8 col-md-8';
 $input_idn = 'industry';
 input_form($input_idn, $input_typen, $input_labeln, $sizen);

 
 
   $input_labelc9 = 'Background Image';
 $input_typec9 = 'text';
 $sizec9 = 'col-xs-8 col-md-8';
 $input_idc9 = 'bgimg';
 input_form($input_idc9, $input_typec9, $input_labelc9, $sizec9);
 
echo "<button class='btn btn-lg btn-primary btn-block' type='submit' name='submit'>Submit</button><br />";
 echo "</form></div>";
 ?>
          
</p>

</div>
<div class='col-6'>
<?php
echo "<h4>Edit Business</h4><p>Use uploaded images you've already added. </h4><p> Add addresses here, such as Head Office, or important branches</p><br />";
$sql = $db->query("SELECT * FROM businessname");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 

echo "<a href='editbusiness.php?id=$row[bus_id]'><i class='far fa-edit'></i> $row[webname]</a>|<a href='deletebusiness.php?id=$row[bus_id]'>delete $row[webname]</a><br />"; 
echo "<a href='addaddressesbusiness.php?id=$row[bus_id]'>Add Addresses for $row[webname] </a>";} 
echo "<h4 style='margin-top:4em;'>Edit Business Addresses</h4><p>Details<p><br />"; 


$sqls = $db->query("SELECT * FROM businessaddress");
while($rows = $sqls->fetchArray(SQLITE3_ASSOC ) ) { 

echo "<a href='editbusinessaddress.php?id=$rows[busad_id]'><i class='far fa-edit'></i> $rows[addressname]</a>|<a href='deletebusinessaddress.php?id=$rows[busad_id]'>delete $rows[addressname]</a><br />"; 
 } 


?>
</div>


</div>
</div></body></html>