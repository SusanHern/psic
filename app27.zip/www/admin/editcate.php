<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../lib.php";
include "../../confadmin.php";
$id = $_REQUEST[ty];
echo "<form action='processeditcate.php' method='post'>";
$sql = $db->query("SELECT * FROM groupcate WHERE gc_id ='$id'");


while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 


echo "$row[gc_title]<br />";
echo "$row[gc_image]<br />";
echo "$row[gc_descp]<br />"; 

  echo "<p><input id='addtitle' name='addtitle' value='$row[gc_title]' type='text'></p><br>";
    echo "<p><input id='adddescp' name='adddescp' value='$row[gc_descp]' placeholder='Comma seperated list of features' type='text'></p><br>";
      echo "<p><input id='addimage' name='addimage' value='$row[gc_image]' placeholder='Image .jpg or .png icon 200px by 200px' type='text'></p><br>";
     
           echo "<input id='id' name='id' value='$id' placeholder='$id' type='text'><br><p> 
               
                  <button id='add_em' class='btn btn-primary' type='submit'> 
                     Go! 
                  </button></form></p><p><div id='resultsp'>gg</div></p>"; 

} 
?>
</div></div>
</div></body></html>
addtitle adddescp addimage id