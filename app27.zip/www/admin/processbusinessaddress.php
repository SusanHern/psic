<?
require "../bootstraptop.php";
require "slide.php";
require "../functions/libsql.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
$tb = "businessaddress";
$connection = "../../confadmin.php";

$nameid = intval($_REQUEST[nameid]);
$addressname = cl($_POST[title]);
$address1 = cl($_POST[address1]);
$address2 = cl($_POST[address2]);
$suburb = cl($_POST[suburb]);
$town = cl($_POST[town]);
$zip = intval($_POST[zip]);
$state = cl($_POST[state]);
$landline = $_POST[landline];
$mobile = $_POST[mobile];
$email = strtolower($_POST[email]);
if (!isset($_REQUEST[nameid]) ) { 
echo "This item does not have an id number, go back and try again."; } else { 
echo "Name $addressname phrase $phrase address1 $address1 address2 $address2 suburb $suburb town $town zip $zip state $state landline $landline mobile $mobile ";
$fieldsarray = array("nameid",
"addressname",
"address1",
"address2",
"suburb",
"town", 
"zip", 
"state", 
"landline",
"mobile", 
"startdate", "email");
$fieldsarray2 = array($nameid,
$addressname,
$address1,
$address2,
$suburb,
$town, 
$zip, 
$state, 
$landline,
$mobile, 
$startdate, $email);
instb($connection, $tb, $fieldsarray, $fieldsarray2);
echo "data added"; } 
?>

</div></div>
</div></body></html>