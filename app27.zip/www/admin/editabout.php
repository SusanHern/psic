<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<script>
function validateForm()
{
var x=document.forms["rform"]["addtype"].value;
if (x==null || x=="")
  {
  alert("Title must be filled out");
  return false;
  } 


var xc=document.forms["rform"]["subhead"].value;
if (xc==null || xc=="")
  {
  alert("phrase must be filled out");
  return false;
  } 
  var xc1=document.forms["rform"]["descp"].value;
if (xc1==null || xc1=="")
  {
  alert("Text must be filled out");
  return false;
  } 
   



}
</script>
<?
include "../../lib.php";
include "../../confadmin.php";
$id = $_REQUEST[id];
$sb = $db->query("SELECT * FROM about WHERE ab_id = '$id'");
while ($row = $sb->fetchArray(SQLITE3_ASSOC) ) { 
           echo "<form enctype='multipart/form-data' name='rform' onsubmit='return validateForm();' action='processeditabout.php' method='post'><label>Title Header</label><br><input id='addtype' value='$row[ab_title]' name='addtype' /><label>Sub Header</label><br><input id='subhead' value='$row[ab_subhead]' name='subhead' />
           <label>Add Image</label><img src='../$row[ab_image]' height='80px' /><br><br><input type='hidden' name='MAX_FILE_SIZE' value='30000000' /><input name='userfile' type='file'  id='userfile' /><br>
           <label>Short Description</label><br>
           <textarea rows='25' cols='50' name='descp'>$row[ab_txt]</textarea><br>
                      <label>Add Date</label><input id='day' name='day' type='date'><br><input type='hidden' name='id' value='$id' />";
                      
   

                  echo "<button id='add_em' class='btn btn-danger' type='submit'> 
                     Go! 
                  </button>";
echo "</form>"; } 
?>
</div></div>
<div class='row'>
<div class='col-12'>
<?
$sq = $db->query("SELECT * FROM about");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 
echo "<a href='editabout.php?id=$row[ab_id]'>$row[ab_title]</a><br>";
} 
?>
</div></div>
</div></body></html>

