<?
require "bootstraptop.php";
require "slide.php";
include "../../bootlib.php";
include "../../confadmin.php";

?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<h4>Order Details</h4>
</div>
</div>
<div class='row'>
<div class='col-12'>

<?


$id = $_REQUEST["id"];

echo "<table class='table-bordered' width='100%'><tr>
      <td><b>Name</b></td>
      <td><b>Description</b></td>
      <td><b>Image</b></td>
      <td><b>Skills</b></td>
      <td><b>Education</b></td>

   

      </tr>";
$sq = $db->query("SELECT * FROM mentor WHERE mn_id = '$id'");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 
echo "<tr><td> $row[mn_title]</td>";
echo "<td> $row[mn_descp]</td>";
echo "<td> $row[mn_image]<img src='$row[mn_image]' height='150px'/></td>";
echo "<td> $row[mn_skills]</td>";
echo "<td> $row[mn_education]</td>
</tr>";


} 
?></table><br><a href='index.php'>Home</a></br></div></div></div>