
<?
$file = "coord.xml";
$y = file_get_contents($file);
$x = strpos($y, "<DisplayPosition>");
$n = strpos($y, "</DisplayPosition>");
$lenght = strlen($y);
$num = $n - $x;
$str1 = substr($y, $x, $num);
echo "$str1<br>";


$la = str_replace('<Latitude>', " ", $str1);
$lap = str_replace('</Latitude>', " ", $la);
$lam = strpos($lap, '<Longitude>');
$last = strpos($lap, '</Longitude>');
$fin = ($lam+11);
$lat1 = substr($lap, 0, $lam);
$lon1 = substr($lap, $fin, $last);
$lat = trim(str_replace("<DisplayPosition>", " ", $lat1) );
$lon = trim(str_replace("</Longitude>", " ", $lon1) );
echo "Latitude :" . $lat . "<br>";
echo "Longitude :" . $lon . "<br>";
$filex = 'my.txt';
$dr = fopen($filex, "w");
$dat = $lat . $lon;
fwrite($dr, $dat);
  ?>
  
 