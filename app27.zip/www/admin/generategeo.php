<?
include "../../confadmin.php";
$file = "../geoff.js";
$fp = fopen($file, "w");
$data = 'var att = "';
fwrite($fp, $data);        

$sql = $db->query("SELECT * FROM groupcl");
         
            while($row = $sql->fetchArray(SQLITE3_ASSOC)) { 
            $img = $row[gr_image];
            $name = $row[gr_title];
            $fname = $row[cp_fname];
            $descp = $row[gr_desco];
            $rate = 5;
            $service = $row[cp_services_offered];
            $type = $row[gr_cateid];
            
            
            $ser3 = $row[gr_descp];
           
            $jobs = 2;
            $link = $row[link];
            $link = 'groupspage.php';
            $lat = $row[gr_lat];
            $lng = $row[gr_lng];
            $link1 = $link . '?id=' . $row[gr_id];
            $dat = $name . "," . $lat . "," . $lng . "," . $link1 . "," . $type . "," . $ser3 . "," . $rate . "|";
$fpx = fopen($file, "a+");           
fwrite($fpx, $dat);  
             
            } 
            $ws = file_get_contents($file);
            $nws = strlen($ws);
            $newstr = substr($ws, 0, -1);
            $fpg = fopen($file, "w");
            fwrite($fpg, $newstr);
            $ndat ='";';
            $fpxe = fopen($file, "a+");           
fwrite($fpxe, $ndat);
echo "<a href='index.php'>Map Listing Generated, return Home</a>";
            ?>
            
             
           
            


