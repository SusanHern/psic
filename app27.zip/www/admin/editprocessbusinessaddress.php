<?
require "../bootstraptop.php";
require "slide.php";
require "../functions/libsql.php";
error_reporting(0);
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
$tb = "businessaddress";
require "../../confadmin.php";
$nameid = $_REQUEST[nameid];
$addressname = $_POST[title];
$address1 = $_POST[address1];
$address2 = $_POST[address2];
$suburb = $_POST[suburb];
$town = $_POST[town];
$zip = $_POST[zip];
$state = $_POST[state];
$landline = $_POST[landline];
$mobile = $_POST[mobile];
$email = $_POST[email];
$id = $_POST[id];
echo "Name $addressname phrase $phrase address1 $address1 address2 $address2 suburb $suburb town $town zip $zip state $state landline $landline mobile $mobile ";
$fieldsarray = array(
"addressname",
"address1",
"address2",
"suburb",
"town", 
"zip", 
"state", 
"landline",
"mobile", 
"startdate", "email");
$fieldsarray2 = array(
$addressname,
$address1,
$address2,
$suburb,
$town, 
$zip, 
$state, 
$landline,
$mobile, 
$startdate, $email);
$sq = $db->query("UPDATE businessaddress SET $fieldsarray[0] = '$fieldsarray2[0]', $fieldsarray[1] = '$fieldsarray2[1]', $fieldsarray[2] = '$fieldsarray2[2]', $fieldsarray[3] = '$fieldsarray2[3]', $fieldsarray[4] = '$fieldsarray2[4]', $fieldsarray[5] = '$fieldsarray2[5]', $fieldsarray[6] = '$fieldsarray2[6]', $fieldsarray[7] = '$fieldsarray2[7]', $fieldsarray[8] = '$fieldsarray2[8]', $fieldsarray[9] = '$fieldsarray2[9]', $fieldsarray[10] = '$fieldsarray2[10]' WHERE busad_id = '$id'");
echo "data added";
?>

</div></div>
</div></body></html>