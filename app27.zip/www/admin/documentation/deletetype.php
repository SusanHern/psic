<?
require "../../../confdocs.php";
$ptype = $_REQUEST[ty];
echo "$ptype deleted sucessfully <a href='addcate.php'>Go back</a><br>";
$db->exec("DELETE FROM docscate WHERE id = '$ptype'");