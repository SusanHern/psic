
<?
include "../bootstraptop.php";
require "../../../confdocs.php";
?>
<style>
.row{margin-top:3em;}
</style>

<div class='container-fluid'>
<div class='row'><div class='col-6'><h4>Archives</h4><ol class="list-unstyled">
          <?
                        $sq6 = $db->query("SELECT * FROM docs");
while($row6 = $sq6->fetchArray(SQLITE3_ASSOC)) { 
$monthdate = $row6[dc_date]; 
$yearar = explode('-', $monthdate);
$nec[] = $yearar[0] . '-' . $yearar[1];

} 
$unday = array_unique($nec);
foreach ($unday as $da) {
          
              echo "<li><a href='docsbydate.php?date=$da'>$da</a></li>"; } 
              ?>
               
 
              
            </ol></div><div class='col-6'><h4>Categories</h4><ol class="list-unstyled">
            <?
                        $sq5 = $db->query("SELECT * FROM docscate");
while($row5 = $sq5->fetchArray(SQLITE3_ASSOC)) { 
              echo "<li><a href='docpage.php?cate=$row5[id]'>$row5[d_title]</a></li>"; } 
              ?>
              </ol></div></div>
            

            
    
        <div class='row'><div class='col-12'>
    <h1>
  
  </a>
</h1>
</div></div>
       
    <div class='row text-center'>
    <div class='col-12'>
    
 <h4>Documentation</h4><p></p></div>
    </div>
   

   <?


 
function limit_words($string, $word_limit)
{
    $words = explode(" ",$string);
    return implode(" ",array_splice($words,0,$word_limit));
}
 
 

               
        $stm = "SELECT COUNT(*) FROM docs";
       $res = $db->query($stm);
            while($ro = $res->fetchArray(SQLITE3_ASSOC)) { 
            $records = $ro['COUNT(*)'];
            
  }
  
 $recordsperpage = 6;
  
  $url = "index.php";
  echo "<div class='row'><div class='col-md-12'>";
 require "../../paging.php";
 echo "<br />";
  include "../../pagx.php";
  echo "</div></div>";
  echo "<br /><hr>";
        

 
 
$sq = $db->query("SELECT * FROM docs ORDER BY dc_id DESC LIMIT $nu, $recordsperpage");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 

$title = $row[dc_title];
$txt = nl2br($row[dc_txt]); 
$txtz = limit_words($txt,40);
$id = $row[dc_id]; 
$day = $row[dc_date]; 



     echo "<div class='row'>
    <div class='col-6'><p><img src='$row[dc_img]' class='img-fluid' /></p></div>";
    

    echo "<div class='col-6'><h4 class='text-left'>$title</h4><p style='color:lime;'>$day</p><p class='text-center'><p>$txtz....</p></div></div>"; 
 echo "<div class='row text-center'>
    <div class='col-md-12'><p>$row[dc_vid]</p><a class='btn btn-secondary' href='blog.php?id=$id' role='button'>Read More</a></div></div>";
       

    } 
    
    
    ?>
   
    

        
          

          

          
       
    
      

   
  
   

   
    <hr>
   

</div>

