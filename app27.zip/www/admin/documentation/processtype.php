<?
require "../../../confdocs.php";
$ptype = $_POST[type];
echo "$ptype added to data<br>";
$db->exec("INSERT INTO docscate(d_title) VALUES('$ptype')");
?>
