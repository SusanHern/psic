<form name='workform' enctype='multipart/form-data' method='post' action='process.php'>
<h2>Docs Post</h2>
<label>Date</label><br>
<input type='date' name='date' /><br>
<label>Link</label><br>
<input type='text' name='link' /><br>
<label>Title</label><br>
<input type='text' name='title' /><br>
<label>Description</label><br>
<input type='text' name='descps' /><br>
<label>Image</label><br><input type='hidden' name='MAX_FILE_SIZE' value='30000000' /><input name='userfile' type='file' id='userfile' />
<label>Text</label><br>
<textarea name ='txt' rows='50' cols='50'></textarea><br>

<label>Video</label><br>
<input type='text' name='vid' /><br>

<label>Category </label><br>

<?
require "../../../confdocs.php";
echo "<select name='cate'>";
$sq = $db->query("SELECT * FROM docscate");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) {

echo "<option value='$row[id]'>$row[d_title]</option><br>";


} 
echo "</select><br>";


echo "<select name='cate1'>";
$sq = $db->query("SELECT * FROM docscate");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) {

echo "<option value='$row[id]'>$row[d_title]</option><br>";


} 
echo "</select><br>";

?>
<input type='submit' value='submit' name='submit' /></form>

