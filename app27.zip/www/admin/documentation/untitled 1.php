adding categories
<iframe width="560" height="315" src="https://www.youtube.com/embed/4D7461JA-rw" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
add group
<iframe width="560" height="315" src="https://www.youtube.com/embed/_vMx5TL3zuc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
add workshop
<iframe width="560" height="315" src="https://www.youtube.com/embed/rQo2YobwvcI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
view workshop