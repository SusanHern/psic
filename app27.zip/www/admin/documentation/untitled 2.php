<?

?>
<style>
#pp{display:none;
background:black;
color:white;}
a{color:white;}
</style>
<div class='btn btn-dark' onclick='al();' id='myp'>Click</div>
<div id='pp'><a href='delete.php?id=$id'>if you are sure you want to delete click here</a></div>
<script>
var mng = 9;
function al() {
document.getElementById("pp").style.display = "block"; 

} 
</script>
<?
$page = "pagename.php";
$data = '<? require "../../confadmin.php";
require "bootstraptop.php";
$db->query("DELETE FROM  WHERE = $id");
echo "<a href='index.php'>Operation Complete Return Home</a><br>"';
touch($page);
$fp = fopen
echo "$page";
?>