<?
require "bootstraptop.php";
require "slide.php";
include "../functions/bootlib.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../lib.php";
include "../../confadmin.php";

$id = $_REQUEST[id];
$cate = $_REQUEST[cate];
echo "$id<br>";
$sq = $db->query("SELECT * FROM workshop2 WHERE ws_groupid = '$id'");
while($row = $sq->fetchArray(SQLITE3_ASSOC) ) { 
echo "$row[ws_title]";
echo "<a href='editworkshop.php?id=$row[ws_id]&&cate=$row[ws_subcateid]&&groupid=$row[ws_groupid]'>$row[ws_title]</a>|<a href='deleteworkshop.php?id=$row[ws_id]'>$row[ws_title]</a><br>";
} 
?>
</div></div>
</div>
</body></html>




?>
</div></div>
</div></body></html>
