br_title, br_descp, br_image, br_supplierid
caption" , "link", "descp", "img", "byline
<?

require "../functions/libsql.php";


$connection = "../../confadmin.php";
$tb = "brand";
$cate = $_POST[brand];
$descps = $_POST[brand_descp];
echo "$cate";




$fieldsarray = array("br_title" , "br_descp");
$fieldsarray2 = array($cate, $descp);

instb($connection, $tb, $fieldsarray, $fieldsarray2);
?>

