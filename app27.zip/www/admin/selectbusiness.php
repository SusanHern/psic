<?
        require "../../confadmin.php";
        $sq = $db->query("SELECT * FROM businessname LIMIT 1");
        
        while($ro = $sq->fetchArray(SQLITE3_ASSOC) ) { 
  echo "<strong>$ro[webname]</strong><br>
  $ro[address1], $ro[address2]<br>
  $ro[suburb], $ro[town], $ro[state], $ro[zip]<br><abbr title='Phone'>P:</abbr> $ro[landline]<br><abbr title='Phone'>P:</abbr> $ro[mobile]</address><address><strong>$ro[webname]</strong><br><a href='mailto:". $ro[email] . "'>". $ro[email] . "</a></address>"; 
  } 
  ?>