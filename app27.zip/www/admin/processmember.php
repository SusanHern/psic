<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
gm_gid, gm_role, gm_userid, gm_status
<?
include "../functions/libsql.php";
$connection = "../../confadmin.php";
$tb = "groupmem";
$gm_userid = $_POST[gm_userid];
$gm_role = $_POST[gm_role];
$gm_gid = $_POST[gm_gid];
$gm_status = $_POST[gm_status];
echo "$gm_userid $gm_role $gm_gid $gm_status";

$fieldsarray = array("gm_gid", "gm_role", "gm_userid", "gm_status");
$fieldsarray2 = array($gm_gid, $gm_role, $gm_userid, $gm_status);

instb($connection, $tb, $fieldsarray, $fieldsarray2);

?>
</div></div>
</div></body></html>