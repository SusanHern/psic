<?
require "bootstraptop.php";
require "slide.php";
require "../functions/libsql.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
$tb = "groupcl";
$connection = "../../confadmin.php";
$title = cl($_POST[addtype]);
echo "$title";
if (EMPTY($_POST[addtype]) ) { 
echo "Please enter a title"; } elseif(EMPTY($_POST[descp])) { 
echo "Description must be added"; } 
elseif(EMPTY($_POST[address1]) ) { 
echo "Street name and numbe must be added"; } 
elseif(EMPTY($_POST[suburb]) ) { 
echo "Suburb must be added"; } 
elseif(EMPTY($_POST[town]) ) { 
echo "Town must be added"; } else { 
$cate = $_POST[cate];
$title = cl($_POST[addtype]);
$image = $_POST[img];
$descp = cl($_POST[descp]);

$address1 = cl($_POST[address1]);
$address2 = cl($_POST[address2]);
$suburb = cl($_POST[suburb]);
$town = cl($_POST[town]);
$zip = cl($_POST[zip]);
$state = cl($_POST[state]);
$landline = $_POST[landline];
$mobile = $_POST[mobile];
$email = $_POST[email];
$active = 1;
$lat = $_POST[lat];
$lng = $_POST[lng];
echo "cate $cate title $title img $image description $descp";
echo "Name $addressname phrase $phrase address1 $address1 address2 $address2 suburb $suburb town $town zip $zip state $state landline $landline mobile $mobile ";
$fieldsarray = array("gr_cateid", "gr_title", "gr_descp", "gr_image", "gr_address1", "gr_address2",  "gr_suburb", "gr_town", "gr_zip", "gr_province", "gr_phone", "gr_mobile", "gr_status", "gr_lat", "gr_lng"); 
$fieldsarray2 = array($cate, $title, $descp, $image, 
$address1,
$address2,
$suburb,
$town, 
$zip, 
$state, 
$landline,
$mobile, 
$active, $lat, $lng);
instb($connection, $tb, $fieldsarray, $fieldsarray2);
echo "<a href='addgroups.php'>Data added, add another group</a><br>";
echo "<a href='index.php'>Home</a><br>";





} 