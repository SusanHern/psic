<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../lib.php";
include "../../confadmin.php";
$sq = $db->query("SELECT * FROM tempord");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 


echo "id $row[tm_id]<br>";
echo "client $row[tm_clientid]<br>";
echo "product $row[tm_wsid]<br>";

echo "date $row[tm_date]<br>";


} 
?>
</div></div>
</div></body></html>