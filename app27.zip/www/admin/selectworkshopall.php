<?
include "../../confadmin.php";
$sq = $db->query("SELECT * FROM workshop2");
while($rowz = $sq->fetchArray(SQLITE3_ASSOC)) { 
echo "group $rowz[ws_groupid]<br>";
echo "subcate $rowz[ws_subcateid]"; 
echo "id $rowz[ws_id]<br>";
echo "$rowz[ws_title]"; } 
?>
