
<style>
#details{
padding:4px;
display:none;
position:absolute;
background:black;
color:white;
margin-top:30px;
z-index:5;


border: 1px solid silver;}
td{
height:90px;
width:90px;
border:1px dotted silver;}
.num{ 
color:teal;
margin-left:2px;
margin-top:-34px;
} 
.ap{
color:#d9534f;
font-size:12px;
}</style><?
include "../../confadmin.php";


        function days_in_month($year, $month) {
return round((mktime(0, 0, 0, $month+1, 1, $year) - mktime(0, 0, 0, $month, 1, $year)) / 86400);
} 
$nowmonth = date("Y-m");
$nowm = $nowmonth . '-01';

$y = strtotime($nowm);
$dr = getdate($y);
$g = $dr["mday"];

$yearb = intval($dr["year"]);
$monthb = $dr["mon"];
$fullmonth = $dr["month"];
$das = days_in_month($yearb, $monthb);
$endmonth = $nowmonth . '-' . $das;
echo "$nowm $endmonth<br>";
echo "<h4>$fullmonth $yearb </h4><br />"; 
$daysarray = range(1, $das, 1);
$appointments = range(1, $das, 1);
$sq = $db->query("SELECT * FROM workshop2 WHERE ws_datefr BETWEEN '$nowm' AND '$endmonth'");
while($rowz = $sq->fetchArray(SQLITE3_ASSOC)) { 
echo "$rowz[ws_datefr]<br>";
$daselect = substr($rowz[ws_datefr], -2);
echo "$daselect<br>";
if(substr($daselect, 0, 1) == 0 ) { 
$nax = substr($daselect, 0);

$appointments[$nax-1] = $rowz[ws_title];
}  else { 
$nax = $daselect; 

$appointments[$nax-1] = "$rowz[ws_timefr] " . " $rowz[ws_title]";
} 
} 



echo "<form name='dateForm' method='post' action='datepage.php'><input style='width:30%;' type='month' name='month' /><input style='width:160px;' type='submit' class='btn btn-sm btn-danger' name='submit' value='Select month' /></form>";

        echo "<center><table width='100%'>
        <tr>";
        for($i=0;$i<7;$i++) { 
        if(strlen($appointments[$i]) < 2) { 
        $ff = " "; } else { 
        $ff = $appointments[$i];
         }
        
        echo "<td><div class='num'>$daysarray[$i]</div><div id='$i' onclick='detailsOf(this.id);' class='ap'>$ff</div></td>"; }
        echo "</tr><tr>";
 echo "<tr>";
        for($i=7;$i<14;$i++) { 
         if(strlen($appointments[$i]) < 3) { 
        $ff = " "; } else { 
        $ff = $appointments[$i];
         }
        echo "<td><div class='num'>$daysarray[$i] </div><div id='$i' onclick='detailsOf(this.id);' class='ap'>$ff</div></td>"; }
        echo "</tr><tr>";
         echo "<tr>";
        for($i=14;$i<21;$i++) { 
          if(strlen($appointments[$i]) < 3) { 
        $ff = " "; } else { 
        $ff = $appointments[$i];
         }
        echo "<td><div class='num'>$daysarray[$i]  </div><div id='$i' onclick='detailsOf(this.id);' class='ap'>$ff</div></td>"; }
        echo "</tr><tr>";
         for($i=21;$i<28;$i++) { 
       
        echo "<td><div class='num'>$daysarray[$i]</div></td>"; }
         
        echo "</tr><tr>";
        for($i=28;$i<$das;$i++) { 
        echo "<td><div class='num'>$daysarray[$i]</div><div id='$i' onclick='detailsOf(this.id);' class='ap'>$ff</div></td>"; }
                echo"</tr>
        </table></center>";
        ?>



</div>
</div>
?>

