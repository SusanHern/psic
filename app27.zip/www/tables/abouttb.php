
<?
include "../../confadmin.php";
   $sql =<<<EOF
      CREATE TABLE about
      (ab_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,

ab_title, ab_subhead, ab_txt, ab_image


);
EOF;

   $ret = $db->exec($sql);
   if(!$ret){
      echo $db->lastErrorMsg();
   } else {
      echo "Table created successfully\n";
   }
   $db->close();
?>