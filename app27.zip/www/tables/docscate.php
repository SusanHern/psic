
<?
require "../functions/libsql.php";
$connection = "../../confadmin.php";
$tb = "docscate";
$idfield = "id";
$fieldsarray = array("d_title");
maketb($connection, $tb, $idfield, $fieldsarray);
?>