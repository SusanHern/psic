
<?
require "../functions/libsql.php";
$connection = "../../confadmin.php";
$tb = "docs";
$idfield = "dc_id";
$fieldsarray = array("dc_date" , "dc_link", "dc_title", "dc_descps", "dc_txt", "dc_vid", "dc_img", "dc_cate");
maketb($connection, $tb, $idfield, $fieldsarray);
?>