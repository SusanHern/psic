
<?
require "../functions/libsql.php";
$connection = "../../confadmin.php";
$tb = "pscat";
$idfield = "ps_id";
$fieldsarray = array("psc_title");
maketb($connection, $tb, $idfield, $fieldsarray);
?>