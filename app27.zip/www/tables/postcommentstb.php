
<?
require "../functions/libsql.php";
$connection = "../../confadmin.php";
$tb = "postcomment";
$idfield = "ptco_id";
$fieldsarray = array("ptco_date" , "ptco_postid", "ptco_txt", "ptco_clientid");
maketb($connection, $tb, $idfield, $fieldsarray);
?>