<?
session_start();

require "bootstraptop.php";
require "functions/bootlib.php";
require "../confad.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Categories >>', 'categories.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);
$_SESSION[customer] = '0526060893';
if(isset($_SESSION[customer]) ) {  
?>
<div class='container-fluid'>
<div class='row text-center'>
<div class='col-12'>
<h1>Change Password</h1><form onsubmit='return validateForm();' name='rform' action='processchps.php' method='post'>
<?
 $input_labela = 'Old Password';
 $input_typea = 'password';
 $sizea = 'col-xs-8 col-md-8';
 $input_ida = 'ops';
 input_form($input_ida, $input_typea, $input_labela, $sizea);
  $input_labela = 'New Password';
 $input_typea = 'password';
 $sizea = 'col-xs-8 col-md-8';
 $input_ida = 'nps';
 input_form($input_ida, $input_typea, $input_labela, $sizea);
  $input_labela = 'New Password Again';
 $input_typea = 'password';
 $sizea = 'col-xs-8 col-md-8';
 $input_ida = 'npsr';
 input_form($input_ida, $input_typea, $input_labela, $sizea);
 echo "<input type='submit' class='btn btn-dark' name='submit' value='Change Password' />";
 echo "</form>";
 ?>
</div></div>





<? } 

else { echo "You must be logged in to proceed"; } 
require "footer.php";
?>




</div><!container>

<?
require "bootstrapbottom.php";
?>