<?
require "bootstraptop.php";
require "functions/bootlib.php";
include "../confad.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Start A Group >>', 'startgroup.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);

echo "<div class='container'>";
echo "<hr>";
$emaila = strtolower($_POST['yemail1']);
$emailb = strtolower($_POST['yemail2']);
echo "$emaila $emailb";
if($emaila != $emailb) { 
echo "That is incorrect, emails do not match"; } 
elseif(empty($_POST['yemail1']) )  { 
echo "Please enter an email"; } else {

echo "emails match"; 
include "../lib.php";
$emaila1 = cr($stp, $emaila, $action = 'enc');
$sq = $db->query("SELECT * FROM cust WHERE cu_email = '$emaila1'");
while($row = $sq->fetchArray(SQLITE3_ASSOC ) ) { 
$email = $row[cu_email];
$id = $row[cu_id];
echo "email $email $row[cu_id]"; } 
if ($email == $emaila1) {
echo "An email has been sent to you, please click on the link to reset your password"; 
$qsq = $db->query("UPDATE cust SET cu_pw_status = '1'  WHERE cu_id = '$id'");
$messagews = "<b>Click on the link to reset your Password </b>$ornum";
$messagebod = 'http://publicinternshipclub.co.za/chpas.php?em=' . "$emaila";
$message = $messagews . $messagebod;
$subject = 'Password reset PISC';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
//Additional headers
$headers .= 'To: Susan <amberjones797@gmail.com>' . "\r\n";
$headers .= 'From: Public Service Internship Club  <admin@publicserviceinternshipclub.co.za>' . "\r\n";
$headers .= 'Cc: susan.hern@icloud.com' . "\r\n";
$headers .= 'Bcc: '; 
$ar = array($emaila . ', ', 'susan.hern@icloud.com, ');
//implode means turn array into a sentence
$headers .=implode(',', $ar);
// Mail it
$to = $emaila;
mail($to, $subject, $message, $headers);
} 
else { 
echo "We do not seem to have your email address in our database, please contact admin to sort out your problem";
} } 





?>