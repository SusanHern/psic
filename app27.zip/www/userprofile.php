<?
require "bootstraptop.php";

?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<script>
function validateForm()
{
var x=document.forms["rform"]["addtype"].value;
if (x==null || x=="")
  {
  alert(" Name must be filled out");
  return false;
  } 


var xc=document.forms["rform"]["descp"].value;
if (xc==null || xc=="")
  {
  alert("Description must be filled out");
  return false;
  } 
  var xc1=document.forms["rform"]["skills"].value;
if (xc1==null || xc1=="")
  {
  alert("Skills must be filled out");
  return false;
  } 
   var xc2=document.forms["rform"]["edu"].value;
if (xc1==null || xc1=="")
  {
  alert("Education must be filled out");
  return false;
  } 



}
</script>
<?
include "../lib.php";
include "../confad.php";

$sq = $db->query("SELECT * FROM cust1 WHERE cu_id = '9'");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 

           echo "<form name='rform' enctype='multipart/form-data' onsubmit='return validateForm();' action='processuser.php' method='post'><label>Name</label><br><input id='addtype' value='$row[cu_fname] $row[cu_lname]' name='addtype' />"; } 
           echo "<br><label>Profile Image</label><br><input type='hidden' name='MAX_FILE_SIZE' value='30000000' /><input name='userfile' type='file' id='userfile' />
           <br>
           <label>Short Personal Description</label><br>
           <textarea rows='10' cols='30' name='descp'></textarea>";
   echo "<br><label>Education/Schools/University</label><br>
           <textarea rows='10' cols='30' name='edu'></textarea><br>";

                  echo "<button id='add_em' class='btn btn-danger' type='submit'> 
                     Go! 
                  </button>";
echo "</form>";
?>
</div></div>
<div class='row'>
<div class='col-12'>
<?
$sq = $db->query("SELECT * FROM cust1");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) { 
echo "<a href='editprofile.php?id=$row[mn_id]'>$row[mn_title]</a><br>";
} 
?>
</div></div>
</div></body></html>
