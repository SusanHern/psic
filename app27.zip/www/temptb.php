
<?
include "../../confadmin.php";
   $sql =<<<EOF
      CREATE TABLE tempord
      (tm_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,

tm_gcid, tm_wsid, tm_clientid, tm_date


);
EOF;

   $ret = $db->exec($sql);
   if(!$ret){
      echo $db->lastErrorMsg();
   } else {
      echo "Table created successfully\n";
   }
   $db->close();
?>