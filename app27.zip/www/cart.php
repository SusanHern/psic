<?
session_start();
error_reporting(0);
if(isset($_SESSION[customer] ) ) { 
require "../lib.php";
require "../confad.php";
$customer = cr($stp, ($_SESSION[customer]), $action = 'enc');
$sqlc = $db->query("SELECT * FROM cust1 WHERE cu_phone_mobile = '$customer'");
while($row = $sqlc->fetchArray(SQLITE3_ASSOC) ) { 
$newcustid = $row[cu_id]; }
$prodid = $_POST[fedits];
echo " $prodid";

$sq = $db->query("SELECT * FROM workshop2 WHERE ws_id = '$prodid'");
while($rowz = $sq->fetchArray(SQLITE3_ASSOC)) { 
echo "$rowz[ws_datefr]<br>";
$datefr = $rowz[ws_datefr];
$title = $rowz[ws_title];
$descp = $rowz[ws_descp];
$image = $rowz[ws_image];
$principle = $rowz[ws_principle];
$price = $rowz[ws_price];
$discount = $rowz[ws_discount];
$criteria = $rowz[ws_discount_criteria];
$group = $rowz[ws_groupid];
$noww = date("Y-m-d");
echo "The Workshop $title has been added to your cart <a href='cartdets.php'>view details</a><br><a href='groupspage.php
?id=$group'>Continue to browse</a> ";
$time = $rowz[ws_timefr];  
$sw = $db->query("INSERT INTO tempord(tm_gcid, tm_wsid, tm_clientid, tm_date) values ('$group', '$prodid', '$newcustid', '$noww')");


}
} else { 

$prodid = $_POST[fedits];
echo "<div class='row'>
<div class='col-12'>
      <form name='rform' onsubmit='return validateForm();' action='inlog4.php' method='post' class='form-signin'>
        <h2 class='form-signin-heading'>Login</h2>
        <label for='input' class='sr-only'>Mobile Number</label>
        <input type='input' name='mobile' id='inputE' class='form-control' placeholder='Mobile number' required autofocus>
        <label for='inputPassword' class='sr-only'>Password</label>
        <input type='password' id='inputPassword' name='password' class='form-control' placeholder='Password' required><input type='text' name='item' value='$prodid' />
        
        <button class='btn btn-md btn-dark btn-block' type='submit'>Sign in</button>
      </form>
</div>

</div>"; 






} 
?>