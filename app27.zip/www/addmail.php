<?php

include "../confad.php";
include "../lib.php";
error_reporting(0);
$emaa = strtolower($_REQUEST[mail]);
echo "$emaa";
 $str = trim($_REQUEST[nam]);
 $str1 = str_replace(' ', '', $str);
 $y = ctype_alpha($str1);
 echo "$str ";
 $emval = strtolower($_REQUEST["mail"]);
$ema6 = cr($stp, $emval, $action = "enc");
$sq = $db->query("SELECT * FROM nleta WHERE nl_em = '$ema6'");
while($row = $sq->fetchArray(SQLITE3_ASSOC) ) { 
$id[] = $row[nl_id]; } 
$co = count($id);
if($co > 0) { 


echo "That address already exists, select another";
 } 
 
elseif(EMPTY($_REQUEST[nam]) ) { 
echo "PLEASE SUPPLY A NAME"; } 
elseif(EMPTY($_REQUEST[mail])) { 
echo "PLEASE SUPPLY EMAIL";

} 
elseif (filter_var($emaa, FILTER_VALIDATE_EMAIL) === false) {
  echo "$emaa is not a valid address" ; } 
 elseif($y != 1) { 
echo "Name must contain letters only.<br />"; 
        } 

else {

$name = $_REQUEST[nam];

$ema2 = strtolower($_REQUEST[mail]);
$ema = cr($stp, $_REQUEST[mail], $action = "enc");
$qs = $db->query("INSERT INTO nleta(nl_name, nl_em, ni_va) values('$name', '$ema', '1')");

echo "Thank you for your subscription. Please click on the link which has been sent to your email to confirm";
$messagews = "<b>Click on the link to validate your email </b>";
$messagebod = 'http://publicserviceinternshipclub.co.za/www/valid.php?em=' . "$ema2";
$message = $messagews . $messagebod;
$subject = 'Newsletter subscription';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
//Additional headers
$headers .= 'To:' . $name .  '<' . $ema2 . '>' . "\r\n";
$headers .= 'From: Public Service Internship Club Webstore <admin@publicserviceinternshipclub.co.za>' . "\r\n";
$headers .= 'Cc: ';
$headers .= 'Bcc: '; 
$ar = array($ema2 . ', ', 'susan.hern@icloud.com, ');
//implode means turn array into a sentence
$headers .=implode(',', $ar);
// Mail it
$to = $ema2;
mail($to, $subject, $message, $headers);

 } 
 ?>
 