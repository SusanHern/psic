<script>
$(document).ready(function(){ 

$("#cart_results").slideUp(); 

    $(".add_cart").click(function(e){ 
        e.preventDefault(); 

        ajax_search(); 
    }); 
     

}); 


function ajax_search(){ 
$("#cout").show();
$("#shop").show();
  $("#cart_results").show(); 
  var item_val=$("#item_name").val();
var item_colour_val = $("#item_colour").val();
var item_size_val = $("#item_size").val();
var quant_val = $("#item_quant").val();
  $.post("cart.php", {item_name : item_val, item_colour : item_colour_val, item_size : item_size_val, quant : quant_val}, function(data){
   if (data.length>0){ 
var ttm = "Your Order<br />";
     $("#cart_results").html(ttm+data); 
   } 
  }) 
} 