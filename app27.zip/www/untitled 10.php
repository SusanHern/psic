<?
require "email_validation.php";
$validator = new email_validation_class;
$validator->timeout = 10;
$validator->debug = TRUE;
$email = "@gmail.com";
if($validator->ValidateEmailBox($email) ) { 
echo "$email valid"; } else { 
echo "not valid";
} 
?>