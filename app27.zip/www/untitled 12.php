<?
session_start();

require "bootstraptop.php";
require "functions/bootlib.php";
require "../confad.php";

error_reporting(0);
?>
<style>

#conf1{padding:10px;
color:#3a4660;
background:; 
border-radius:0px 30px 30px 0px;}
#confirm{background:;}

#conf2{padding:10px;
color:#3a4660;
background:#ceb7a2;
border-right:1px solid #eee7e0;
border-radius:0px 30px 30px 0px;}
#conf3{padding:10px;
color:#3a4660;
background:;
border-right:1px solid #ceb7a2;
border-radius:0px 30px 30px 0px; }
</style>
<?
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Categories >>', 'categories.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);
echo "<div class='container-fluid'>";
$_SESSION['customer'] = "0526060893";

if(isset($_SESSION['customer'] && !EMPTY($_POST[em])) { 
require "../lib.php";
echo "cookie $_COOKIE[cust]";
$customer = cr($stp, ($_COOKIE[cust]), $action = 'enc');
$sqlc = $db->query("SELECT * FROM cust1 WHERE cu_phone_mobile = '$customer'");
while($row = $sqlc->fetchArray(SQLITE3_ASSOC) ) { 
$newcustid = $row[cu_id]; 
$sub = $row[cu_subscriptionstatus];

} 
$id = "confirm";
$size = 3;
$rule = 'text-center';
$colsize = 'col-4';
$gg = array('conf1', 'conf2', 'conf3');
$contentarray[0] = "<h5>Confirm >></h5>";
$contentarray[1] = "<h5>Payment >></h5>";
$contentarray[2] = "<h5>Notification >></h5>";
rowcol($id, $rule, $size, $contentarray, $colsize, $gg);

$sql = $db->query("SELECT * FROM ordnum");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
$numold = $row[od_num]; 
$numnew = $numold + 1;} 
echo "<div class='row'>
<div class='col-12 text-center'><h4>Confirm Details of your Purchase before Checkout</h4></div></div>";
echo "<table width='100%'><tr><td>Workshop</td><td>Price</td><td>Date</td><td>Time</td><td>Discount</td><td></td></tr>";
$sq = $db->query("SELECT
        tempord.tm_wsid,
        tempord.tm_clientid,
        workshop2.ws_id,
        workshop2.ws_title,
        workshop2.ws_price,
        workshop2.ws_datefr,
        workshop2.ws_timefr,
        workshop2.ws_timeto,
        workshop2.ws_discount,
        workshop2.ws_descp
        
FROM tempord  

INNER JOIN workshop2 ON
        tempord.tm_wsid = workshop2.ws_id WHERE tempord.tm_clientid = '9'");
        while($rowg = $sq->fetchArray(SQLITE3_ASSOC ) ) { 

               if($sub == 'y') { 
        
        $newprice = $rowg[ws_price] - ($rowg[ws_price] * ($rowg[ws_discount]/100)); } else { $newprice = $rowg[ws_price]; } 
        $wsid = $rowg[ws_id];
        echo "wk id $wsid<br>";
        $discountcr = $rowg[ws_discount_criteria];
        $ft = $rowg[ws_descp];
        $totadds[] = $newprice;
           $mobile = $_POST[mb];
$emailx = $_POST[em];
$fname = $_POST[name_first];
$lname = $_POST[name_last];
$email = cr($stp, $_POST[em], $action = 'enc');
$sq = $db->query("UPDATE cust1 SET cu_fname = '$fname',  cu_lname = '$lname', cu_contact_title = '$contacttitle', cu_email = '$email' WHERE cu_id = '$newcustid'");
$pt = $_POST[paytype];
$ti = 'workshop';
$subad = $_POST[subad];
$orstatus = 2;

$tb = "wsorders";


$day = date("Y-m-d");
$timep = date("H:i");

  
        
        echo "<tr><td>$rowg[ws_title]</td>";
echo "<td>R $rowg[ws_price]</td>";
echo "<td>$rowg[ws_datefr]</td>";
echo "<td><b>From:</b> $rowg[ws_timefr]<br>";
echo "<b>To:</b> $rowg[ws_timeto]</td>";
echo "<td>$rowg[ws_discount] %</td><td></td></tr>";
$sw = $db->query("INSERT INTO wsorders(wo_ordernum, wo_clientid, wo_wsid, wo_producttype, wo_price, wo_orderdate, wo_ordertime, wo_discounttype, wo_discountamount, wo_orderfeatures, wo_orderstatus, wo_paymenttype, wo_paymentstatus) values('$numnew', '$newcustid', '$wsid', '$ti', '$newprice', '$day', '$timep', '$discountcr', '$discountamount', '$ft', '$orstatus', '$pt', '1')");   
        } 
        $total = array_sum($totadds);
        echo "<tr><td colspan='6'></td><td>R $total</td></tr></table>";

$xz = $db->query("UPDATE ordnum SET od_num = '$numnew'");
$id = 'tsty';
$rowcount = 2;
$conte = array('Name', 'Name', 'Mobile', 'Email', 'Payment Method', 'Product', 'Total', $fname, $lname, $_SESSION[customer], $emailx, $pt, $ti, $total);
$tableclass = 'table table-bordered';
?>
        
</div></div><div style='margin-top:5em;' class='row'>
<div class='col-12'><h4 style='color:#ceb7a2;'>Payment Details</h4>
<?
btable($id, $tableclass, $rowcount, $conte, $optsid);
?>
<h4 style='color:#ceb7a2;'>Payfast</h4><p>You will be directed to the Payfast, secure payment gateway. we do not store card details on this website.</p><p>No shipping details are necassary for this product.</p>
</div>
</div>

 
<?php
// Construct variables 
$cartTotal = $total;
$data = array(
    // Merchant details
    'merchant_id' => '10010678',
    'merchant_key' => 'agwrp9i76eqco',
    'return_url' => "https://www.publicserviceinternshipclub.co.za/www/success.php?payid=$numnew",
    'cancel_url' => "https://www.publicserviceinternshipclub.co.za/www/cancel.php?payid=$numnew",
    'notify_url' => "https://www.publicserviceinternshipclub.co.za/www/notify.php?payid=$numnew",
    // Buyer details
    'name_first' => $fname,
    'name_last'  => $lname,
    'email_address'=> 'sbtu01@payfast.co.za',
    // Transaction details
    'm_payment_id' => $numnew, 
    
    
    'amount' => number_format( sprintf( "%.2f", $total ), 2, '.', '' ),
    'item_name' => 'workshops',
    'item_description' => 'Details of workshop on your account',
    'custom_int1' => $newcustid,           
    'custom_str1' => 'Thank you for your purchase' . $_SESSION[customer]
);        

// Create GET string
$pfOutput = '';
foreach( $data as $key => $val )
{
    if(!empty($val))
     {
        $pfOutput .= $key .'='. urlencode( trim( $val ) ) .'&';
     }
}

$getString = substr( $pfOutput, 0, -1 );

$passPhrase = 'amagreatGirl44';
if( isset( $passPhrase ) )
{
    $getString .= '&passphrase='. urlencode( trim( $passPhrase ) );
}   
$data['signature'] = md5( $getString );


$testingMode = true;
$pfHost = $testingMode ? 'sandbox.payfast.co.za' : 'www.payfast.co.za';
$htmlForm = '<form action="https://'.$pfHost.'/eng/process" method="post">'; 
foreach($data as $name=> $value)
{ 
    $htmlForm .= '<input name="'.$name.'" type="hidden" value="'.$value.'" />'; 
} 
$htmlForm .= '<input class="btn btn-dark" type="submit" value="Pay Now" /></form>'; 
echo $htmlForm;
$ema2 = $_POST[em];
$messagews = "<b>Thank you for your purchase. Welcome to workshops Details of your purchase are available on your account </b>";
$messagebod = 'https://publicserviceinternshipclub.co.za/www/ypage.php';
$messagenext = "A total of $total has been request form Payfast. A Confirmation email will arrive shortlyif the payment is sucessful.";
$message = $messagews . $messagebod;
$subject = 'Workshop Purchase';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
//Additional headers
$headers .= 'To:' . $fname . $lname . '<' . $ema2 . '>' . "\r\n";
$headers .= 'From: Public Service Internship Club Webstore <admin@publicserviceinternshipclub.co.za>' . "\r\n";
$headers .= 'Cc: ';
$headers .= 'Bcc: '; 
$ar = array($ema2 . ', ', 'susan.hern@icloud.com, ');
//implode means turn array into a sentence
$headers .=implode(',', $ar);
// Mail it
$to = $ema2;
mail($to, $subject, $message, $headers);

 
} else { 
echo "<a href='login.php'>Please login to access this information</a>"; } 
include "footer.php";
include "bootstrapbottom.php";
?>
</div>
