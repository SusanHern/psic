<?
session_start();

require "bootstraptop.php";
require "functions/bootlib.php";
require "../confad.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Start A Group >>', 'startgroup.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);

if(isset($_SESSION[customer]) ) {  
?>
<div class='container-fluid'>

<?

require "../lib.php";
$email = cr($stp, $_POST[em], $action = 'enc');
$fname = $_POST[name_first];
$lname = $_POST[name_last];
$contacttitle = $_POST[contacttitle];
$customer = cr($stp, $_SESSION[customer], $action = 'enc');
$sqlc = $db->query("SELECT * FROM cust1 WHERE cu_phone_mobile = '$customer'");
while($row = $sqlc->fetchArray(SQLITE3_ASSOC) ) { 
$newcustid = $row[cu_id];
echo "Thank you<br />";

 } 
echo " $fname $lname $contacttitle<br>";

$sq = $db->query("UPDATE cust1 SET cu_fname = '$fname',  cu_lname = '$lname', cu_contact_title = '$contacttitle', cu_email = '$email' WHERE cu_id = '$newcustid'");


?>



<? } 

else { echo "You must be logged in to proceed"; } 
require "footer.php";
?>










</div><!container>

<?
require "bootstrapbottom.php";
?>