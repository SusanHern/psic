<?
session_start();
require "bootstraptop.php";
require "functions/bootlib.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Categories >>', 'categories.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);
?>


<div class='container-fluid'>





<div style='margin-top:2em;' class='row text-center'>

<div class='col-2'><i style='color:#eee7e0;' class="fas fa-graduation-cap"></i><p>Learn</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-chalkboard"></i><p>Teach</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-chalkboard-teacher"></i><p>Meet</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-chalkboard"></i><p>Connect</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-laptop"></i><p>Improve</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-desktop"></i><p>Instruct</p>
</div>


 

</div>


<div  style='background: #f4efea;' class='row text-center'>

<div style='padding:10px;border-bottom:1px solid #ed8a63;background:#f4efea;' class='col-12'>
<h2>About Us</h2>
<h4>Striving for Education</h4>
<p style='color:#ed8a63;'>------ <i class="fab fa-twitter fa-1x" style='color:#ed8a63;'></i><i class="fab fa-instagram fa-1x" style='color:#ed8a63;'></i><i class="fab fa-facebook-f fa-1x" style='color:#ed8a63;'></i> ------</p><p>This is an online job resource which organizes Meet Up Groups on Internship.</p>
<p>Public Service Internship club is an online resource which aims to assist learners who are currently on an internship Programme within the Public Service to get online and join quarterly organized Provincial Workshops on increasing chances of securing permanent employment within the Public Service.</p>
<p>Organized training, job notices , coaching sessions , CV enhancement,  Online workshops on  mastering interviews, Meet Up Group Facilitation. </p>
</div></div>

 <div class="card-group">
     <div class="card"><div class="card-header text-center">Maria Dube</div>
      <img class="card-img-top img-fluid" src="pep2.jpg" alt="Card image cap">
    
    <div class="card-body">
      <h5 class="card-title">Srtiving for excellence</h5>
      <p style='color:#ceb7a2;' class="card-text">Started comany in year......</p>
    </div>
    <div class="card-footer text-center">
      <h4 class="text-muted text-center">2018</h4>
    </div>
  </div>
  
<div class="card"><div class="card-header text-center">John Doe</div>
      <img class="card-img-top img-fluid" src="pep1.jpg" alt="Card image cap">
    
    <div class="card-body">
      <h5 class="card-title">Assisting Students</h5>
      <p style='color:#ceb7a2;' class="card-text">Dedicated to improving education.</p><p>
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
    </div>
    <div class="card-footer text-center">
      <h4 class="text-muted text-center">2018</h4>
    </div>
  </div></div>
    
<?
require "../confad.php";
require "footer.php";
?>


</div><!container>

<?
require "bootstrapbottom.php";
?>

