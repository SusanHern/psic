<?
include "../confad.php";
include "../lib.php";
if (!isset($_POST[upload]) )  
{ 
echo "<form enctype='multipart/form-data' action='$_SERVER[PHP_SELF]' method='POST'>";
$title = 'title';
$des = 'des';
echo "<b>Enter title</b><br />";
text($title);
echo "<br />";
echo "<b>Give a short description</b><br />";
$ro = 10;
$co = 20;
texta($des, $ro, $co);
echo "<br />";
echo"<input type='hidden' name='MAX_FILE_SIZE' value='30000000' /><input name='userfile' type='file' id='userfile' /><br /><input name='upload' type='submit' style='background-color:black;color:blue;border:1px solid brown;' id='upload' value='Upload'></form>";
} 
else 
{  
print_r($_FILES);
print_r($_POST);
$ar = array('png' , 'jpg' , 'gif');
$title = $_POST[title];
$des = $_POST[des];
echo $_FILES['userfile'] ['tmp_name'];
echo "<br />";
if (isset($_ENV['WINDIR'] ) ) 
{ 
$fil1 = str_replace("\\\\", "\\", $_FILES['userfile'] ['name']);
$fil = substr($fil1, -3);
if ($fil != $ar['0'] || $fil != $ar['1'] || $fil != $ar['2']) 
{ 
echo "You have uploaded a file in the wrong formatt, only jpg, gif or png allowed"; 
} 
} 
else 
{ 
$fileName = $_FILES['userfile'] ['name'];
$tmpName = $_FILES['userfile'] ['tmp_name'];
$fileSize = $_FILES['userfile'] ['size'];
$fp = fopen($tmpName, 'r');
$content = fread($fp, $fileSize);
$content = addslashes($content);
fclose($fp);
$picture = str_replace(' ', '_', $tmpName);
$source = $picture;
$target = 'pic/' . $fileName;
move_uploaded_file($source, $target );

echo "File<b> $fileName</b> uploaded as id= $id<br>";

$sql = "INSERT INTO im(us, ps, img, ti, des, timestamp) values($us, $ps, $target, $title, $des, $day)";
$res = $db->query($sql);

echo "File<b> $fileName</b> uploaded<br>";
echo "<b>thank-you for your submission</b></br >"; 
} } 
?>
