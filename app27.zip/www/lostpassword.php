<?
require "bootstraptop.php";
require "functions/bootlib.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Start A Group >>', 'startgroup.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);
?>
<div class="container">

      <div class="row">
        <div class="col-md-12">
          <h4>Reset Password. <span class="text-muted">You must have entered an email address in your delivery details to recover a password using this method. Otherwise contact website admin to reset.</span></h4>
          <p class="lead">Follow procedure below.</p>
        
       
      

<?

echo "<h4>Enter your email address and we will send you a link to reset your password</h4>";
echo "<form action='resetps.php' method='post'><label>Email</label>";
echo "<input type='text' name='yemail1' /><br />";
echo "<label>Confirm email</label>";
echo "<input type='text' name='yemail2' /><br />";
echo "<button type='submit' name='submit' class='btn btn-sm btn-danger'>Send</button></form>";
?> </div></div>
