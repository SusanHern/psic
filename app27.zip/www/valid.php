<?
session_start();
error_reporting(0);
require "bootstraptop.php";
require "functions/bootlib.php";
require "../confad.php";
require "../lib.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Categories >>', 'categories.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);


?>
<div class='container-fluid'>
<div class='row'>
<div class='col-12'>
<?
$ema = strtolower($_REQUEST[em]);
$ema6 = cr($stp, $ema, $action = "enc");
$sq = $db->query("SELECT * FROM nleta WHERE nl_em = '$ema6' AND ni_va = '1'");
while($row = $sq->fetchArray(SQLITE3_ASSOC) ) { 
$emm = $row[nl_em];
$id = $row[nl_id];
 } 
 if(strlen($emm) < 1) { 
 echo "You have already validated this email address"; } 
 else { 
 $sqa = $db->query("UPDATE nleta SET ni_va = '2' WHERE nl_id = '$id'");
 echo "Thank you for validating your address, we will be sending you our Newsletter, from time to time";
 
 } 
 ?>
</div></div>





<? 
require "footer.php";
?>




</div><!container>

<?
require "bootstrapbottom.php";
?>
