<?
session_start();
error_reporting(0);
require "bootstraptop.php";
require "functions/bootlib.php";
require "../confad.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Categories >>', 'categories.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);
?>


<div class='container-fluid'>





<div style='margin-top:2em;' class='row text-center'>

<div class='col-2'><i style='color:#eee7e0;' class="fas fa-graduation-cap"></i><p>Learn</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-chalkboard"></i><p>Teach</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-chalkboard-teacher"></i><p>Meet</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-chalkboard"></i><p>Connect</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-laptop"></i><p>Improve</p>
</div>
<div class='col-2'><i style='color:#eee7e0;' class="fas fa-desktop"></i><p>Instruct</p>
</div>


 

</div>


<div  style='background: #f4efea;' class='row text-center'>

<div style='padding:10px;border-bottom:1px solid #ed8a63;background:#f4efea;' class='col-12'>
<?
$sq = $db->query("SELECT * FROM about WHERE ab_id = '1'");
while($row = $sq->fetchArray(SQLITE3_ASSOC) ) { 
echo "<h2>$row[ab_title]</h2>
<h4>$row[ab_subhead]</h4>
<p style='color:#ed8a63;'><i class='fab fa-twitter fa-1x' style='color:#ed8a63;'></i><i class='fab fa-instagram fa-1x' style='color:#ed8a63;'></i><i class='fab fa-facebook-f fa-1x' style='color:#ed8a63;'></i></p><p>$row[ab_txt] </p>"; } 
?> 
</div></div>

 <div class="card-group">
     <div class="card">
     <?
     $sqx = $db->query("SELECT * FROM about WHERE ab_id = '2'");
while($rowx = $sqx->fetchArray(SQLITE3_ASSOC) ) { 
     echo "<div class='card-header text-center'>$rowx[ab_title]</div>
      <img class='card-img-top img-fluid' src='$rowx[ab_image]' alt='$rowx[ab_title]'>
    
    <div class='card-body'>
      <h5 class='card-title'>$rowx[ab_subhead]</h5>
      <p style='color:#ceb7a2;' class='card-text'>$rowx[ab_txt]</p>
    </div>
    <div class='card-footer text-center'>
      <h4 class='text-muted text-center'>$rowx[ab_date]</h4>"; } 
      ?>
    </div>
  </div>
  
<div class="card">
<?
 $sqxc = $db->query("SELECT * FROM about WHERE ab_id = '3'");
while($rowxc = $sqxc->fetchArray(SQLITE3_ASSOC) ) { 
echo "<div class='card-header text-center'>$rowxc[ab_title]</div>
      <img class='card-img-top img-fluid' src='$rowxc[ab_image]' alt='$rowxc[ab_title]'>
    
    <div class='card-body'>
      <h5 class='card-title'>$rowxc[ab_sbhead]</h5>
      <p style='color:#ceb7a2;' class='card-text'>Dedicated to improving education.</p><p>
<p>$rowxc[ab_txt]</p>
    </div>
    <div class='card-footer text-center'>
      <h4 class='text-muted text-center'>$rowxc[ab_date]</h4>"; } 
      ?>
    </div>
  </div></div>
    
<?
require "../confad.php";
require "footer.php";
?>


</div><!container>

<?
require "bootstrapbottom.php";
?>

