<?
$title = 'Public Service Internship Club Pricing';
require "bootstraptop.php";
require "functions/bootlib.php";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Public Service Internship Club';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Start A Group >>', 'startgroup.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);
?>

<div class='container-fluid'>
<?
include "../confad.php";
         $sql = $db->query("SELECT * FROM subscription LIMIT 0, 30 ");
while($row = $sql->fetchArray(SQLITE3_ASSOC ) ) { 
        $features = explode(',', $row[sb_descp]);
echo "<div class='row'>

 

<div style='width:100%;margin-bottom:60%;' class='col-12'>
<div class='card mb-5 mb-lg-0'>
          <div class='card-body'>

 
            <h5 class='card-title text-muted text-uppercase text-center'>" . $row[sb_repeat] . "/Subscription</h5>
            <h6 class='card-price text-center'>R" . $row[sb_price] . "<span class='period'>/Year</span></h6>
            <hr>
            <ul class='fa-ul'>
              <li><span style='color:;' class='fa-li'><i class='fas fa-check'></i></span>" . $features[0] . "</li>
              <li><span style='color:;' class='fa-li'><i class='fas fa-check'></i></span>" . $features[1] . "</li>
              <li><span style='color:;' class='fa-li'><i class='fas fa-check'></i></span>" . $features[2] . "</li>
              <li><span style='color:;' class='fa-li'><i class='fas fa-check'></i></span>" . $features[3] . "</li>
      
            </ul>
            <a style='margin-right:10px;background:#ed8a63;color:gray;' href='buy.php?sb_id=$row[sb_id]' class='btn btn-md text-uppercase'>Buy Now</a>
          </div>
        
      


</div>"; } 

?>
 









<?

require "footer.php";
echo "</div><!container>";
require "bootstrapbottom.php";
?>